---
name: Enterprise Inventory System
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#45464d'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#515f74'
  on-secondary: '#ffffff'
  secondary-container: '#d5e3fd'
  on-secondary-container: '#57657b'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#0b1c30'
  on-tertiary-container: '#75859d'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#d5e3fd'
  secondary-fixed-dim: '#b9c7e0'
  on-secondary-fixed: '#0d1c2f'
  on-secondary-fixed-variant: '#3a485c'
  tertiary-fixed: '#d3e4fe'
  tertiary-fixed-dim: '#b7c8e1'
  on-tertiary-fixed: '#0b1c30'
  on-tertiary-fixed-variant: '#38485d'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  data-mono:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 40px
  container-max: 1440px
  gutter: 20px
---

## Brand & Style

This design system is engineered for high-density data environments and enterprise-grade inventory management. The brand personality is rooted in reliability, precision, and institutional stability. It utilizes a **Corporate / Modern** design style, prioritizing information architecture over decorative elements. 

The aesthetic is characterized by a "Safe" visual identity—utilizing a sober palette and industry-standard typography to minimize cognitive load for analysts. The goal is to evoke a sense of controlled authority, where the UI recedes to allow critical technology metrics and hardware lifecycle data to take center stage. High-contrast treatments are reserved strictly for key performance indicators (KPIs) and actionable status alerts.

## Colors

The palette is built on a foundation of "Deep Ocean" blues and slate grays to maintain a professional, low-fatigue environment. 

- **Primary (#0F172A):** Used for navigation sidebars, primary headings, and deep-state UI elements. It provides the "anchor" for the interface.
- **Secondary/Tertiary:** Variations of slate are used for secondary text, icons, and borders to create a clear hierarchy without introducing unnecessary color.
- **Neutral:** A crisp white surface is complemented by a very light slate background (`#F8FAFC`) to distinguish between the canvas and the data containers.
- **Semantic Accents:** Vibrant tones are used sparingly for data visualization and status indicators (e.g., "In Stock", "Depreciated", "Maintenance Required").

## Typography

Inter is selected for its exceptional legibility in data-heavy contexts and its neutral, utilitarian character. 

- **Headlines:** Use Bold and Semi-Bold weights to denote clear section starts. Display sizes are used for high-level KPI dashboards.
- **Body:** Standardized at 14px for density, ensuring that complex tables and inventory lists remain readable.
- **Data Display:** Numerical values in tables and charts should utilize "tabular numbers" (fixed-width figures) to ensure columns of data align perfectly for quick visual scanning.
- **Labels:** Small, uppercase labels with increased tracking are used for metadata and table headers to distinguish them from interactive content.

## Layout & Spacing

The design system employs a **Fixed Grid** philosophy for dashboard views to ensure consistency across standard enterprise monitor resolutions (1920x1080).

- **Grid:** A 12-column grid is used for the main content area, with a fixed 240px left-hand navigation sidebar.
- **Spacing Rhythm:** Based on a 4px baseline. Gutters are set to 20px to provide breathing room between dense data cards.
- **Padding:** Data containers (cards) use 24px internal padding for high-level summaries and 16px for detailed data tables to maximize vertical space.
- **Mobile Reflow:** On smaller screens, the 12-column grid collapses to a single column, and the sidebar transforms into a bottom navigation bar or a collapsed "hamburger" drawer.

## Elevation & Depth

To maintain a "sober" corporate aesthetic, this system avoids heavy shadows and dramatic depth. Instead, it uses **Low-Contrast Outlines** and **Tonal Layers**.

- **Surface Levels:** The primary background is `#F8FAFC`. White (`#FFFFFF`) is used for the interactive "cards" or "containers" that hold data.
- **Borders:** Containers are defined by a subtle 1px border (`#E2E8F0`) rather than a shadow. This creates a crisp, "engineered" look.
- **Active States:** Subtle 2px bottom borders in Primary Navy are used to indicate active tabs or navigation items.
- **Modal Elevation:** Only critical overlays (like "Add Asset" forms) use a soft, 15% opacity slate shadow to draw focus away from the background dashboard.

## Shapes

The shape language is conservative and professional. 

- **Standard Radius:** 0.25rem (4px) is the default for buttons, input fields, and small cards. This "Soft" edge feels modern but remains grounded in traditional corporate UI.
- **Container Radius:** Larger layout blocks (main dashboard sections) use 0.5rem (8px) to provide a gentle distinction from the edge of the screen.
- **Data Markers:** Chart elements (bars, legend markers) utilize sharp edges (0px radius) to emphasize mathematical precision.

## Components

- **Buttons:** Primary buttons are solid `#0F172A` with white text. Secondary buttons use a ghost style with a slate border. All buttons use 4px rounding.
- **KPI Cards:** Prominent 1-column containers featuring a `label-md` header, a `display-lg` metric, and a small trend sparkline at the bottom.
- **Inventory Tables:** Use zebra-striping with `#F8FAFC` for every second row. Headers are sticky and use the `#F1F5F9` background with `label-md` typography.
- **Status Chips:** Small, low-saturation backgrounds with high-saturation text (e.g., Light Green background with Deep Green text) for lifecycle statuses like "Active" or "Retired."
- **Search & Filter:** Input fields feature a minimalist search icon and a 1px slate border that thickens to 2px Primary Navy on focus.
- **Navigation Sidebar:** High-contrast Navy background with "Slate-300" icons. Active items are highlighted with a vertical 4px bar on the left edge.