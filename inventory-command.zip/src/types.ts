export type NavigationTab = 'dashboard' | 'location' | 'management' | 'analytics' | 'reports';

export type AssetStatus = 'Active' | 'Maintenance' | 'Retired' | 'In Transit';

export interface Asset {
  id: string;
  type: string;
  category: 'Computing' | 'Networking' | 'Storage' | 'Peripherals' | 'Mobile Devices' | 'Displays';
  location: string;
  region: 'North America' | 'Europe' | 'Asia Pacific';
  department: 'IT Infrastructure' | 'Logistics' | 'Facilities' | 'Engineering';
  status: AssetStatus;
  deploymentDate: string;
  serialNumber: string;
  assignedTo?: string;
  healthScore?: number;
  lastMaintenance?: string;
  cost?: number;
}

export interface Transaction {
  id: string;
  type: 'Entrega' | 'Consumo';
  destination: string;
  units: number;
  status: 'Completed' | 'Pending' | 'Cancelled';
  date: string;
  time: string;
  operator: string;
  assetCategory?: string;
}

export interface FacilityLocation {
  id: string;
  name: string;
  region: 'North America' | 'Europe' | 'Asia Pacific';
  city: string;
  country: string;
  activeAssets: number;
  capacityUtilization: number;
  deliveriesThisMonth: number;
  consumptionThisMonth: number;
  status: 'Optimal' | 'Warning' | 'Maintenance';
}

export interface FilterState {
  region: string;
  department: string;
  searchQuery: string;
  status: string;
}
