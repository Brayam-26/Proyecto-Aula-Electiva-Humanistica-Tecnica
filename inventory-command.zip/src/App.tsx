import React, { useState, useEffect } from 'react';
import {
  NavigationTab,
  Asset,
  Transaction,
  FacilityLocation,
  FilterState,
  AssetStatus,
} from './types';
import {
  INITIAL_ASSETS,
  INITIAL_TRANSACTIONS,
  INITIAL_LOCATIONS,
  USER_AVATAR_MOBILE_URL,
} from './data/mockData';
import { Sidebar } from './components/Sidebar';
import { TopHeader } from './components/TopHeader';
import { DashboardView } from './components/DashboardView';
import { MobileDashboardView } from './components/MobileDashboardView';
import { LocationView } from './components/LocationView';
import { ManagementView } from './components/ManagementView';
import { AnalyticsView } from './components/AnalyticsView';
import { ReportsView } from './components/ReportsView';
import { MobileBottomNav } from './components/MobileBottomNav';
import { MobileDrawer } from './components/MobileDrawer';
import { AssetDetailModal } from './components/AssetDetailModal';
import { NewAssetModal } from './components/NewAssetModal';
import { ExportModal } from './components/ExportModal';
import { NotificationDrawer } from './components/NotificationDrawer';
import { SettingsSupportModal } from './components/SettingsSupportModal';

export default function App() {
  const [currentTab, setCurrentTab] = useState<NavigationTab>('dashboard');
  const [assets, setAssets] = useState<Asset[]>(INITIAL_ASSETS);
  const [transactions, setTransactions] = useState<Transaction[]>(INITIAL_TRANSACTIONS);
  const [locations] = useState<FacilityLocation[]>(INITIAL_LOCATIONS);

  const [filterState, setFilterState] = useState<FilterState>({
    region: 'All Regions',
    department: 'All Departments',
    searchQuery: '',
    status: 'All',
  });

  // Simulator mode: 'responsive' (adapts to viewport), 'desktop' (enforces Image 2 layout), or 'mobile' (enforces Image 4 layout)
  const [viewMode, setViewMode] = useState<'responsive' | 'desktop' | 'mobile'>('responsive');

  // Modals & Drawers
  const [selectedAsset, setSelectedAsset] = useState<Asset | null>(null);
  const [showNewAssetModal, setShowNewAssetModal] = useState(false);
  const [showExportModal, setShowExportModal] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showMobileDrawer, setShowMobileDrawer] = useState(false);
  const [settingsSupport, setSettingsSupport] = useState<{
    isOpen: boolean;
    tab: 'settings' | 'support';
  }>({
    isOpen: false,
    tab: 'settings',
  });

  // 14 critical alerts as indicated by the KPI card
  const [alerts, setAlerts] = useState([
    {
      id: 'ALT-01',
      title: 'Capacidad Crítica - Data Center Alpha',
      desc: 'Almacenamiento SAN al 94% de capacidad. Se requiere provisión inmediata.',
      severity: 'critical' as const,
      time: 'Hace 10 min',
    },
    {
      id: 'ALT-02',
      title: 'Fallo de Redundancia en Switch AST-9875',
      desc: 'Puerto redundante B caído en Bldg 4 - Piso 2.',
      severity: 'critical' as const,
      time: 'Hace 25 min',
    },
    {
      id: 'ALT-03',
      title: 'Mantenimiento preventivo vencido AST-8421',
      desc: 'Workstation Pro requiere cambio de pasta térmica y diagnóstico CAD.',
      severity: 'warning' as const,
      time: 'Hace 1 hora',
    },
    {
      id: 'ALT-04',
      title: 'Sensor de temperatura DC Beta',
      desc: 'Pico térmico de 27.8°C registrado en Pasillo Frío 4.',
      severity: 'critical' as const,
      time: 'Hace 2 horas',
    },
    {
      id: 'ALT-05',
      title: 'Desconexión de Gateway Tokio',
      desc: 'Reconexión automática tras 42 segundos de interrupción.',
      severity: 'warning' as const,
      time: 'Hace 4 horas',
    },
  ]);

  // Handle asset status updates
  const handleUpdateStatus = (assetId: string, newStatus: AssetStatus) => {
    setAssets((prev) =>
      prev.map((a) => (a.id === assetId ? { ...a, status: newStatus } : a))
    );
    if (selectedAsset && selectedAsset.id === assetId) {
      setSelectedAsset({ ...selectedAsset, status: newStatus });
    }
  };

  // Handle asset deletion
  const handleDeleteAsset = (assetId: string) => {
    setAssets((prev) => prev.filter((a) => a.id !== assetId));
  };

  // Handle adding new asset
  const handleAddAsset = (newAsset: Asset) => {
    setAssets((prev) => [newAsset, ...prev]);
    // Also record an automatic Entrega transaction
    const newTrx: Transaction = {
      id: `TRX-${Math.floor(9800 + Math.random() * 199)}`,
      type: 'Entrega',
      destination: newAsset.location,
      units: 1,
      status: 'Completed',
      date: new Date().toISOString().slice(0, 10),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      operator: 'Administrador del Sistema',
      assetCategory: newAsset.category,
    };
    setTransactions((prev) => [newTrx, ...prev]);
  };

  // Handle adding new transaction
  const handleAddTransaction = (newTrx: Transaction) => {
    setTransactions((prev) => [newTrx, ...prev]);
  };

  const handleDismissAlert = (id: string) => {
    setAlerts((prev) => prev.filter((a) => a.id !== id));
  };

  // Determine if we should display in mobile view
  // If viewMode is mobile, always render mobile view; if viewMode is desktop, force desktop sidebar; if responsive, use CSS classes
  const isForcedMobile = viewMode === 'mobile';
  const isForcedDesktop = viewMode === 'desktop';

  return (
    <div className="min-h-screen bg-[#f7f9fb] text-[#191c1e] flex flex-col antialiased">
      {/* If forced mobile container simulator */}
      {isForcedMobile ? (
        <div className="w-full bg-[#e6e8ea] min-h-screen py-4 flex justify-center items-start">
          <div className="w-full max-w-md bg-[#f7f9fb] min-h-[844px] shadow-2xl rounded-2xl border border-[#c6c6cd] overflow-hidden flex flex-col relative">
            {/* Top mobile simulator bar */}
            <div className="bg-[#f2f4f6] px-4 py-2 border-b border-[#c6c6cd] flex justify-between items-center text-[11px] text-[#45464d]">
              <span className="font-semibold">Simulador Móvil (Imagen 4)</span>
              <button
                onClick={() => setViewMode('responsive')}
                className="hover:text-[#000000] underline cursor-pointer"
              >
                Volver a Responsive
              </button>
            </div>

            {/* Mobile Top Header */}
            <header className="bg-white border-b border-[#c6c6cd] flex justify-between items-center w-full px-4 h-[56px] sticky top-0 z-40">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowMobileDrawer(true)}
                  className="p-1 text-[#000000] cursor-pointer hover:bg-[#f2f4f6] rounded"
                  aria-label="Menu"
                >
                  <span className="material-symbols-outlined text-[24px]">menu</span>
                </button>
                <span className="text-[18px] text-[#000000] font-bold tracking-tight">
                  Inventory Command
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowNotifications(true)}
                  className="relative p-1 text-[#45464d] hover:text-[#000000] cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[20px]">notifications</span>
                  {alerts.length > 0 && (
                    <span className="absolute top-1 right-1 w-2 h-2 bg-[#ba1a1a] rounded-full" />
                  )}
                </button>
                <div
                  onClick={() => setSettingsSupport({ isOpen: true, tab: 'settings' })}
                  className="w-8 h-8 rounded-full bg-[#e0e3e5] overflow-hidden border border-[#c6c6cd] cursor-pointer"
                >
                  <img
                    alt="User profile"
                    className="w-full h-full object-cover"
                    src={USER_AVATAR_MOBILE_URL}
                  />
                </div>
              </div>
            </header>

            {/* Mobile Main Content */}
            <main className="flex-1 p-4 pb-20 overflow-y-auto">
              {currentTab === 'dashboard' && (
                <MobileDashboardView
                  transactions={transactions}
                  onViewAllTransactions={() => setCurrentTab('reports')}
                />
              )}
              {currentTab === 'location' && (
                <LocationView
                  locations={locations}
                  assets={assets}
                  onSelectAsset={(asset) => setSelectedAsset(asset)}
                />
              )}
              {currentTab === 'management' && (
                <ManagementView
                  assets={assets}
                  onSelectAsset={(asset) => setSelectedAsset(asset)}
                  onOpenNewAssetModal={() => setShowNewAssetModal(true)}
                  onOpenExport={() => setShowExportModal(true)}
                  onUpdateStatus={handleUpdateStatus}
                />
              )}
              {currentTab === 'analytics' && <AnalyticsView />}
              {currentTab === 'reports' && (
                <ReportsView
                  transactions={transactions}
                  onAddTransaction={handleAddTransaction}
                  onOpenExport={() => setShowExportModal(true)}
                />
              )}
            </main>

            {/* Mobile Bottom Navigation */}
            <MobileBottomNav
              currentTab={currentTab}
              onSelectTab={(tab) => setCurrentTab(tab)}
              onOpenMore={() => setShowMobileDrawer(true)}
            />
          </div>
        </div>
      ) : (
        /* Responsive or Desktop Layout (Image 2) */
        <div className="flex w-full min-h-screen">
          {/* Desktop Left Sidebar */}
          <div className={isForcedDesktop ? 'block' : 'hidden md:block'}>
            <Sidebar
              currentTab={currentTab}
              onSelectTab={(tab) => setCurrentTab(tab)}
              onOpenExport={() => setShowExportModal(true)}
              onOpenSettings={() => setSettingsSupport({ isOpen: true, tab: 'settings' })}
              onOpenSupport={() => setSettingsSupport({ isOpen: true, tab: 'support' })}
            />
          </div>

          {/* Main Content Area */}
          <main
            id="main-app-content"
            className={`flex-1 flex flex-col min-h-screen ${
              isForcedDesktop ? 'ml-[240px]' : 'md:ml-[240px]'
            }`}
          >
            {/* Top Navigation Bar */}
            <TopHeader
              searchQuery={filterState.searchQuery}
              onSearchChange={(q) => setFilterState({ ...filterState, searchQuery: q })}
              onToggleMobileMenu={() => setShowMobileDrawer(true)}
              onToggleNotifications={() => setShowNotifications(true)}
              onOpenSettings={() => setSettingsSupport({ isOpen: true, tab: 'settings' })}
              unreadAlertsCount={alerts.length}
              viewMode={viewMode}
              onChangeViewMode={(mode) => setViewMode(mode)}
            />

            {/* Screen Content */}
            <div className="flex-1 pb-16 md:pb-6">
              {currentTab === 'dashboard' && (
                <div>
                  {/* On small mobile screens in responsive mode, show the specialized mobile layout from Image 4 */}
                  <div className="block md:hidden p-4">
                    <MobileDashboardView
                      transactions={transactions}
                      onViewAllTransactions={() => setCurrentTab('reports')}
                    />
                  </div>
                  {/* On medium+ screens, show the full Desktop Operations Overview from Image 2 */}
                  <div className="hidden md:block">
                    <DashboardView
                      assets={assets}
                      filterState={filterState}
                      onFilterChange={(newF) => setFilterState({ ...filterState, ...newF })}
                      onSelectAsset={(asset) => setSelectedAsset(asset)}
                      onOpenNewAssetModal={() => setShowNewAssetModal(true)}
                      onViewAllAssets={() => setCurrentTab('management')}
                      criticalAlertsCount={14}
                    />
                  </div>
                </div>
              )}

              {currentTab === 'location' && (
                <LocationView
                  locations={locations}
                  assets={assets}
                  onSelectAsset={(asset) => setSelectedAsset(asset)}
                />
              )}

              {currentTab === 'management' && (
                <ManagementView
                  assets={assets}
                  onSelectAsset={(asset) => setSelectedAsset(asset)}
                  onOpenNewAssetModal={() => setShowNewAssetModal(true)}
                  onOpenExport={() => setShowExportModal(true)}
                  onUpdateStatus={handleUpdateStatus}
                />
              )}

              {currentTab === 'analytics' && <AnalyticsView />}

              {currentTab === 'reports' && (
                <ReportsView
                  transactions={transactions}
                  onAddTransaction={handleAddTransaction}
                  onOpenExport={() => setShowExportModal(true)}
                />
              )}
            </div>

            {/* Mobile Bottom Navigation (only on small screens in responsive mode) */}
            <div className={isForcedDesktop ? 'hidden' : 'block md:hidden'}>
              <MobileBottomNav
                currentTab={currentTab}
                onSelectTab={(tab) => setCurrentTab(tab)}
                onOpenMore={() => setShowMobileDrawer(true)}
              />
            </div>
          </main>
        </div>
      )}

      {/* Global Modals & Drawers */}
      <AssetDetailModal
        asset={selectedAsset}
        onClose={() => setSelectedAsset(null)}
        onUpdateStatus={handleUpdateStatus}
        onDeleteAsset={handleDeleteAsset}
      />

      {showNewAssetModal && (
        <NewAssetModal
          locations={locations}
          onClose={() => setShowNewAssetModal(false)}
          onAddAsset={handleAddAsset}
        />
      )}

      {showExportModal && (
        <ExportModal
          assets={assets}
          transactions={transactions}
          onClose={() => setShowExportModal(false)}
        />
      )}

      <NotificationDrawer
        isOpen={showNotifications}
        onClose={() => setShowNotifications(false)}
        alerts={alerts}
        onDismissAlert={handleDismissAlert}
      />

      <MobileDrawer
        isOpen={showMobileDrawer}
        currentTab={currentTab}
        onSelectTab={(tab) => setCurrentTab(tab)}
        onClose={() => setShowMobileDrawer(false)}
        onOpenExport={() => setShowExportModal(true)}
        onOpenSettings={() => setSettingsSupport({ isOpen: true, tab: 'settings' })}
        onOpenSupport={() => setSettingsSupport({ isOpen: true, tab: 'support' })}
      />

      {settingsSupport.isOpen && (
        <SettingsSupportModal
          initialTab={settingsSupport.tab}
          onClose={() => setSettingsSupport({ ...settingsSupport, isOpen: false })}
        />
      )}
    </div>
  );
}
