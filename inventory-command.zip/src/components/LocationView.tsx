import React, { useState } from 'react';
import { FacilityLocation, Asset } from '../types';

interface LocationViewProps {
  locations: FacilityLocation[];
  assets: Asset[];
  onSelectAsset: (asset: Asset) => void;
}

export const LocationView: React.FC<LocationViewProps> = ({
  locations,
  assets,
  onSelectAsset,
}) => {
  const [selectedRegion, setSelectedRegion] = useState<string>('All');
  const [activeLocationId, setActiveLocationId] = useState<string>(locations[0]?.id || '');

  const filteredLocations = locations.filter((loc) => {
    if (selectedRegion !== 'All' && loc.region !== selectedRegion) return false;
    return true;
  });

  const activeLocation = locations.find((l) => l.id === activeLocationId) || locations[0];
  const locationAssets = assets.filter((a) => a.location === activeLocation?.name);

  return (
    <div className="p-6 md:p-10 max-w-[1440px] mx-auto w-full space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end pb-4 border-b border-[#c6c6cd] gap-4">
        <div>
          <h2 className="text-[24px] font-semibold text-[#191c1e] tracking-tight">
            Facility & Regional Operations
          </h2>
          <p className="text-[14px] text-[#45464d] mt-1">
            Gestión geográfica de depósitos, centros de cómputo y distribución regional.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[12px] font-medium text-[#45464d]">Región:</span>
          {['All', 'North America', 'Europe', 'Asia Pacific'].map((r) => (
            <button
              key={r}
              onClick={() => setSelectedRegion(r)}
              className={`px-3 py-1 rounded text-[12px] font-medium border transition-colors cursor-pointer ${
                selectedRegion === r
                  ? 'bg-[#000000] text-white border-[#000000]'
                  : 'bg-white text-[#45464d] border-[#c6c6cd] hover:bg-[#f2f4f6]'
              }`}
            >
              {r}
            </button>
          ))}
        </div>
      </div>

      {/* Facilities Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredLocations.map((loc) => {
          const isSelected = loc.id === activeLocationId;
          return (
            <div
              key={loc.id}
              onClick={() => setActiveLocationId(loc.id)}
              className={`bg-white border rounded-[2px] p-5 cursor-pointer transition-all shadow-2xs ${
                isSelected
                  ? 'border-[#000000] ring-1 ring-[#000000] bg-[#fcfdfe]'
                  : 'border-[#c6c6cd] hover:border-[#76777d]'
              }`}
            >
              <div className="flex justify-between items-start mb-3">
                <div>
                  <h3 className="text-[16px] font-bold text-[#191c1e]">{loc.name}</h3>
                  <p className="text-[12px] text-[#45464d]">
                    {loc.city}, {loc.country} • <span className="font-medium">{loc.region}</span>
                  </p>
                </div>
                <span
                  className={`px-2 py-0.5 rounded text-[11px] font-semibold ${
                    loc.status === 'Optimal'
                      ? 'bg-[#dcfce7] text-[#166534]'
                      : 'bg-[#fef08a] text-[#854d0e]'
                  }`}
                >
                  {loc.status}
                </span>
              </div>

              {/* Progress bar */}
              <div className="space-y-1.5 my-3">
                <div className="flex justify-between text-[11px] text-[#45464d]">
                  <span>Capacidad de almacenamiento</span>
                  <span className="font-semibold text-[#191c1e]">{loc.capacityUtilization}%</span>
                </div>
                <div className="w-full h-2 bg-[#e0e3e5] rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all ${
                      loc.capacityUtilization > 85 ? 'bg-[#ba1a1a]' : 'bg-[#0F172A]'
                    }`}
                    style={{ width: `${loc.capacityUtilization}%` }}
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 pt-3 border-t border-[#c6c6cd] text-[11px]">
                <div>
                  <span className="text-[#45464d] block">Activos</span>
                  <span className="font-bold text-[#191c1e] text-[13px]">{loc.activeAssets}</span>
                </div>
                <div>
                  <span className="text-[#45464d] block">Entregas</span>
                  <span className="font-bold text-[#16a34a] text-[13px]">+{loc.deliveriesThisMonth}</span>
                </div>
                <div>
                  <span className="text-[#45464d] block">Consumo</span>
                  <span className="font-bold text-[#ba1a1a] text-[13px]">-{loc.consumptionThisMonth}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Location Inventory Detail */}
      {activeLocation && (
        <div className="bg-white border border-[#c6c6cd] rounded-[2px] p-6 shadow-2xs space-y-4">
          <div className="flex flex-col sm:flex-row justify-between sm:items-center pb-3 border-b border-[#c6c6cd] gap-2">
            <div>
              <h3 className="text-[18px] font-bold text-[#191c1e] flex items-center gap-2">
                <span className="material-symbols-outlined text-[#000000]">warehouse</span>
                Inventario local: {activeLocation.name}
              </h3>
              <p className="text-[12px] text-[#45464d]">
                {locationAssets.length} activos catalogados en esta instalación física.
              </p>
            </div>
            <div className="text-[12px] bg-[#f2f4f6] px-3 py-1 rounded text-[#191c1e] font-medium border border-[#c6c6cd]">
              ID Sede: {activeLocation.id}
            </div>
          </div>

          {locationAssets.length === 0 ? (
            <div className="p-8 text-center text-[#45464d] text-sm">
              No hay activos asignados actualmente a esta instalación.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse zebra-stripes">
                <thead>
                  <tr className="bg-[#eceef0] text-[12px] font-medium border-b border-[#c6c6cd] text-[#191c1e]">
                    <th className="p-3 font-semibold">Asset ID</th>
                    <th className="p-3 font-semibold">Tipo</th>
                    <th className="p-3 font-semibold">Categoría</th>
                    <th className="p-3 font-semibold">Gerencia</th>
                    <th className="p-3 font-semibold">Estado</th>
                    <th className="p-3 font-semibold text-right">Acción</th>
                  </tr>
                </thead>
                <tbody className="text-[13px]">
                  {locationAssets.map((asset) => (
                    <tr key={asset.id} className="border-b border-[#c6c6cd] hover:bg-[#f2f4f6]">
                      <td className="p-3 font-mono font-bold text-[#191c1e]">{asset.id}</td>
                      <td className="p-3 font-medium text-[#191c1e]">{asset.type}</td>
                      <td className="p-3 text-[#45464d]">{asset.category}</td>
                      <td className="p-3 text-[#45464d]">{asset.department}</td>
                      <td className="p-3">
                        <span
                          className={`inline-flex px-2 py-0.5 rounded-full text-xs font-semibold ${
                            asset.status === 'Active'
                              ? 'bg-[#dcfce7] text-[#166534]'
                              : asset.status === 'Maintenance'
                              ? 'bg-[#fef08a] text-[#854d0e]'
                              : 'bg-[#fee2e2] text-[#991b1b]'
                          }`}
                        >
                          {asset.status}
                        </span>
                      </td>
                      <td className="p-3 text-right">
                        <button
                          onClick={() => onSelectAsset(asset)}
                          className="text-[#000000] font-semibold hover:underline cursor-pointer"
                        >
                          Details
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
