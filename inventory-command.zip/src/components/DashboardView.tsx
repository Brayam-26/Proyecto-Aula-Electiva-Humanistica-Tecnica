import React, { useState } from 'react';
import { Asset, FilterState } from '../types';
import { BarChartDistribution } from './charts/BarChartDistribution';
import { LineChartConsumption } from './charts/LineChartConsumption';

interface DashboardViewProps {
  assets: Asset[];
  filterState: FilterState;
  onFilterChange: (newFilter: Partial<FilterState>) => void;
  onSelectAsset: (asset: Asset) => void;
  onOpenNewAssetModal: () => void;
  onViewAllAssets: () => void;
  criticalAlertsCount: number;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  assets,
  filterState,
  onFilterChange,
  onSelectAsset,
  onOpenNewAssetModal,
  onViewAllAssets,
  criticalAlertsCount,
}) => {
  const [showCategoryMenu, setShowCategoryMenu] = useState(false);
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string | null>(null);

  // Filter assets based on region, department, category, and search query
  const filteredAssets = assets.filter((asset) => {
    if (filterState.region !== 'All Regions' && asset.region !== filterState.region) {
      return false;
    }
    if (filterState.department !== 'All Departments' && asset.department !== filterState.department) {
      return false;
    }
    if (selectedCategoryFilter && asset.category !== selectedCategoryFilter) {
      return false;
    }
    if (filterState.searchQuery) {
      const q = filterState.searchQuery.toLowerCase();
      const match =
        asset.id.toLowerCase().includes(q) ||
        asset.type.toLowerCase().includes(q) ||
        asset.location.toLowerCase().includes(q) ||
        asset.department.toLowerCase().includes(q) ||
        asset.category.toLowerCase().includes(q);
      if (!match) return false;
    }
    return true;
  });

  const getStatusBadge = (status: Asset['status']) => {
    switch (status) {
      case 'Active':
        return (
          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-[#dcfce7] text-[#166534] border border-[#bbf7d0]">
            Active
          </span>
        );
      case 'Maintenance':
        return (
          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-[#fef08a] text-[#854d0e] border border-[#fde047]">
            Maintenance
          </span>
        );
      case 'Retired':
        return (
          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-[#fee2e2] text-[#991b1b] border border-[#fecaca]">
            Retired
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-[#e0e3e5] text-[#45464d]">
            {status}
          </span>
        );
    }
  };

  return (
    <div className="p-6 md:p-10 max-w-[1440px] mx-auto w-full space-y-6">
      {/* Page Header & Filters */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end pb-4 border-b border-[#c6c6cd] gap-4">
        <div>
          <h2 className="text-[24px] font-semibold text-[#191c1e] tracking-tight">
            Operations Overview
          </h2>
          <p className="text-[14px] text-[#45464d] mt-1">
            Real-time metrics and inventory status across all regions.
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-4">
          {/* Localidad Filter */}
          <div className="flex flex-col">
            <label className="text-[12px] font-medium text-[#45464d] mb-1">Localidad</label>
            <select
              id="filter-localidad-select"
              value={filterState.region}
              onChange={(e) => onFilterChange({ region: e.target.value })}
              className="bg-white border border-[#c6c6cd] rounded-[2px] px-3 py-1 text-[14px] text-[#191c1e] focus:border-[#000000] focus:ring-1 focus:ring-[#000000] h-8 min-w-[150px] cursor-pointer"
            >
              <option value="All Regions">All Regions</option>
              <option value="North America">North America</option>
              <option value="Europe">Europe</option>
              <option value="Asia Pacific">Asia Pacific</option>
            </select>
          </div>

          {/* Gerencia Filter */}
          <div className="flex flex-col">
            <label className="text-[12px] font-medium text-[#45464d] mb-1">Gerencia</label>
            <select
              id="filter-gerencia-select"
              value={filterState.department}
              onChange={(e) => onFilterChange({ department: e.target.value })}
              className="bg-white border border-[#c6c6cd] rounded-[2px] px-3 py-1 text-[14px] text-[#191c1e] focus:border-[#000000] focus:ring-1 focus:ring-[#000000] h-8 min-w-[150px] cursor-pointer"
            >
              <option value="All Departments">All Departments</option>
              <option value="IT Infrastructure">IT Infrastructure</option>
              <option value="Logistics">Logistics</option>
              <option value="Facilities">Facilities</option>
              <option value="Engineering">Engineering</option>
            </select>
          </div>

          {/* Quick Action Button */}
          <div className="flex flex-col justify-end">
            <button
              id="dashboard-new-asset-btn"
              onClick={onOpenNewAssetModal}
              className="h-8 px-3 bg-[#000000] text-white text-[12px] font-medium rounded-[2px] hover:bg-[#131b2e] transition-colors flex items-center gap-1 cursor-pointer"
            >
              <span className="material-symbols-outlined text-[16px]">add</span>
              <span>Nuevo Activo</span>
            </button>
          </div>
        </div>
      </div>

      {/* Top Grid: KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {/* KPI 1 */}
        <div
          id="kpi-entregas-card"
          className="bg-white border border-[#c6c6cd] rounded-[2px] p-6 flex flex-col justify-between h-[140px] shadow-2xs hover:border-[#76777d] transition-colors"
        >
          <div className="flex justify-between items-start">
            <h3 className="text-[12px] font-medium text-[#45464d] uppercase tracking-wider">
              Entregas Totales
            </h3>
            <span className="material-symbols-outlined text-[#45464d] text-[20px]">
              local_shipping
            </span>
          </div>
          <div>
            <div className="text-[36px] font-bold text-[#191c1e] leading-tight tracking-tight">
              12,450
            </div>
            <div className="flex items-center gap-1 mt-1 text-[12px]">
              <span className="material-symbols-outlined text-[#16a34a] text-[16px]">
                trending_up
              </span>
              <span className="text-[#16a34a] font-medium">+4.2%</span>
              <span className="text-[#45464d] ml-1">vs last month</span>
            </div>
          </div>
        </div>

        {/* KPI 2 */}
        <div
          id="kpi-consumo-card"
          className="bg-white border border-[#c6c6cd] rounded-[2px] p-6 flex flex-col justify-between h-[140px] shadow-2xs hover:border-[#76777d] transition-colors"
        >
          <div className="flex justify-between items-start">
            <h3 className="text-[12px] font-medium text-[#45464d] uppercase tracking-wider">
              Consumo Mensual
            </h3>
            <span className="material-symbols-outlined text-[#45464d] text-[20px]">
              monitoring
            </span>
          </div>
          <div>
            <div className="text-[36px] font-bold text-[#191c1e] leading-tight tracking-tight">
              3,291
            </div>
            <div className="flex items-center gap-1 mt-1 text-[12px]">
              <span className="material-symbols-outlined text-[#dc2626] text-[16px]">
                trending_down
              </span>
              <span className="text-[#dc2626] font-medium">-1.5%</span>
              <span className="text-[#45464d] ml-1">vs last month</span>
            </div>
          </div>
        </div>

        {/* KPI 3 */}
        <div
          id="kpi-active-assets-card"
          className="bg-white border border-[#c6c6cd] rounded-[2px] p-6 flex flex-col justify-between h-[140px] shadow-2xs hover:border-[#76777d] transition-colors"
        >
          <div className="flex justify-between items-start">
            <h3 className="text-[12px] font-medium text-[#45464d] uppercase tracking-wider">
              Active Assets
            </h3>
            <span className="material-symbols-outlined text-[#45464d] text-[20px]">
              devices
            </span>
          </div>
          <div>
            <div className="text-[36px] font-bold text-[#191c1e] leading-tight tracking-tight">
              {assets.filter((a) => a.status === 'Active').length > 0 ? '8,902' : '0'}
            </div>
            <div className="flex items-center gap-1 mt-1 text-[12px]">
              <span className="text-[#45464d]">Across 14 locations</span>
            </div>
          </div>
        </div>

        {/* KPI 4 */}
        <div
          id="kpi-alerts-card"
          className="bg-white border border-[#c6c6cd] rounded-[2px] p-6 flex flex-col justify-between h-[140px] shadow-2xs hover:border-[#ba1a1a] transition-colors"
        >
          <div className="flex justify-between items-start">
            <h3 className="text-[12px] font-medium text-[#45464d] uppercase tracking-wider">
              Critical Alerts
            </h3>
            <span className="material-symbols-outlined text-[#ba1a1a] text-[20px]">
              error
            </span>
          </div>
          <div>
            <div className="text-[36px] font-bold text-[#ba1a1a] leading-tight tracking-tight">
              {criticalAlertsCount}
            </div>
            <div className="flex items-center gap-1 mt-1 text-[12px]">
              <span className="text-[#45464d]">Requires immediate attention</span>
            </div>
          </div>
        </div>
      </div>

      {/* Middle Grid: Bento-style Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Bar Chart: Inventory by Category (Spans 2 columns) */}
        <div className="bg-white border border-[#c6c6cd] rounded-[2px] p-6 lg:col-span-2 flex flex-col shadow-2xs">
          <div className="flex justify-between items-center mb-4 relative">
            <div>
              <h3 className="text-[20px] font-semibold text-[#191c1e]">
                Inventory Distribution by Category
              </h3>
              {selectedCategoryFilter && (
                <div className="flex items-center gap-1 text-[11px] text-[#45464d] mt-0.5">
                  <span>Filtrado por: <strong>{selectedCategoryFilter}</strong></span>
                  <button
                    onClick={() => setSelectedCategoryFilter(null)}
                    className="text-[#ba1a1a] hover:underline ml-1 cursor-pointer"
                  >
                    (Limpiar)
                  </button>
                </div>
              )}
            </div>
            <div className="relative">
              <button
                id="chart-more-options-btn"
                onClick={() => setShowCategoryMenu(!showCategoryMenu)}
                className="text-[#45464d] hover:text-[#000000] p-1 rounded hover:bg-[#f2f4f6] cursor-pointer"
                aria-label="Más opciones"
              >
                <span className="material-symbols-outlined text-[20px]">more_horiz</span>
              </button>

              {showCategoryMenu && (
                <div className="absolute right-0 top-8 bg-white border border-[#c6c6cd] shadow-lg rounded py-1 z-20 w-44 text-[12px]">
                  <button
                    onClick={() => {
                      setSelectedCategoryFilter(null);
                      setShowCategoryMenu(false);
                    }}
                    className="w-full text-left px-3 py-1.5 hover:bg-[#f2f4f6] text-[#191c1e]"
                  >
                    Mostrar todas las categorías
                  </button>
                  <button
                    onClick={() => {
                      setSelectedCategoryFilter('Computing');
                      setShowCategoryMenu(false);
                    }}
                    className="w-full text-left px-3 py-1.5 hover:bg-[#f2f4f6] text-[#191c1e]"
                  >
                    Filtrar solo Computing
                  </button>
                  <button
                    onClick={() => {
                      setSelectedCategoryFilter('Networking');
                      setShowCategoryMenu(false);
                    }}
                    className="w-full text-left px-3 py-1.5 hover:bg-[#f2f4f6] text-[#191c1e]"
                  >
                    Filtrar solo Networking
                  </button>
                </div>
              )}
            </div>
          </div>
          <div className="flex-1 min-h-[300px] w-full">
            <BarChartDistribution onCategoryClick={(cat) => setSelectedCategoryFilter(cat)} />
          </div>
        </div>

        {/* Line Chart: Consumption Trends (Spans 1 column) */}
        <div className="bg-white border border-[#c6c6cd] rounded-[2px] p-6 flex flex-col shadow-2xs">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-[20px] font-semibold text-[#191c1e]">
              Consumption Trends
            </h3>
            <span className="text-[12px] font-medium bg-[#e0e3e5] px-2 py-0.5 rounded-[2px] text-[#45464d] tracking-wide">
              YTD
            </span>
          </div>
          <div className="flex-1 min-h-[300px] w-full">
            <LineChartConsumption />
          </div>
        </div>
      </div>

      {/* Bottom Section: Data Table */}
      <div
        id="recent-assets-section"
        className="bg-white border border-[#c6c6cd] rounded-[2px] overflow-hidden shadow-2xs"
      >
        <div className="p-4 border-b border-[#c6c6cd] flex justify-between items-center bg-[#f7f9fb]">
          <div className="flex items-center gap-2">
            <h3 className="text-[20px] font-semibold text-[#191c1e]">
              Recent Technology Assets
            </h3>
            <span className="text-[12px] bg-[#e0e3e5] text-[#45464d] px-2 py-0.5 rounded-full font-medium">
              {filteredAssets.length} activos
            </span>
          </div>
          <button
            id="view-all-assets-btn"
            onClick={onViewAllAssets}
            className="border border-[#76777d] text-[#191c1e] px-4 py-1.5 rounded-[2px] text-[12px] font-medium hover:bg-[#e6e8ea] transition-colors cursor-pointer"
          >
            View All
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse zebra-stripes">
            <thead>
              <tr className="bg-[#eceef0] text-[#191c1e] text-[12px] font-medium border-b border-[#c6c6cd] tracking-wide">
                <th className="p-4 font-semibold">Asset ID</th>
                <th className="p-4 font-semibold">Type</th>
                <th className="p-4 font-semibold">Location</th>
                <th className="p-4 font-semibold">Status</th>
                <th className="p-4 font-semibold">Deployment Date</th>
                <th className="p-4 font-semibold text-right">Action</th>
              </tr>
            </thead>
            <tbody className="text-[14px] text-[#191c1e]">
              {filteredAssets.slice(0, 6).map((asset) => (
                <tr
                  key={asset.id}
                  id={`asset-row-${asset.id}`}
                  className="border-b border-[#c6c6cd] last:border-b-0 hover:bg-[#f2f4f6] transition-colors"
                >
                  <td className="p-4 font-mono font-semibold text-[14px] text-[#191c1e]">
                    {asset.id}
                  </td>
                  <td className="p-4">
                    <div className="font-medium text-[#191c1e]">{asset.type}</div>
                    <div className="text-[12px] text-[#45464d]">{asset.category}</div>
                  </td>
                  <td className="p-4 text-[#45464d]">{asset.location}</td>
                  <td className="p-4">{getStatusBadge(asset.status)}</td>
                  <td className="p-4 text-[#45464d]">{asset.deploymentDate}</td>
                  <td className="p-4 text-right">
                    <button
                      id={`action-details-${asset.id}`}
                      onClick={() => onSelectAsset(asset)}
                      className="text-[#000000] hover:underline text-[12px] font-semibold cursor-pointer py-1 px-2 hover:bg-[#e0e3e5] rounded transition-colors"
                    >
                      Details
                    </button>
                  </td>
                </tr>
              ))}
              {filteredAssets.length === 0 && (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-[#45464d] text-[14px]">
                    No se encontraron activos con los filtros seleccionados.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
