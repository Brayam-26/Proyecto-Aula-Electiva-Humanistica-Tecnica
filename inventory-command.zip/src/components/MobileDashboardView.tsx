import React from 'react';
import { Transaction } from '../types';
import { WeeklyTrendChart } from './charts/WeeklyTrendChart';

interface MobileDashboardViewProps {
  transactions: Transaction[];
  onSelectTransaction?: (trx: Transaction) => void;
  onViewAllTransactions: () => void;
}

export const MobileDashboardView: React.FC<MobileDashboardViewProps> = ({
  transactions,
  onSelectTransaction,
  onViewAllTransactions,
}) => {
  return (
    <div className="space-y-4 pb-12">
      {/* Page Header */}
      <div>
        <h1 className="text-[24px] font-semibold text-[#191c1e] tracking-tight">
          Dashboard
        </h1>
        <p className="text-[14px] text-[#45464d] mt-0.5">
          Overview of Entregas and Consumos
        </p>
      </div>

      {/* KPI Stack (Mobile Vertical) */}
      <div className="flex flex-col gap-4">
        {/* KPI: Entregas */}
        <div
          id="mobile-kpi-entregas"
          className="bg-white rounded-lg border border-[#c6c6cd] p-6 shadow-2xs"
        >
          <div className="flex justify-between items-start mb-2">
            <span className="text-[12px] font-medium text-[#45464d] uppercase tracking-wider">
              Total Entregas
            </span>
            <span className="material-symbols-outlined text-[#000000] text-[22px]">
              local_shipping
            </span>
          </div>
          <div className="text-[36px] font-bold text-[#191c1e] mb-2 leading-tight">
            1,245
          </div>
          <div className="flex items-center gap-1">
            <span className="material-symbols-outlined text-[#0F172A] text-sm">
              trending_up
            </span>
            <span className="font-semibold text-sm text-[#0F172A]">+12.5%</span>
            <span className="text-[12px] text-[#45464d] ml-2">vs last month</span>
          </div>
        </div>

        {/* KPI: Consumos */}
        <div
          id="mobile-kpi-consumos"
          className="bg-white rounded-lg border border-[#c6c6cd] p-6 shadow-2xs"
        >
          <div className="flex justify-between items-start mb-2">
            <span className="text-[12px] font-medium text-[#45464d] uppercase tracking-wider">
              Total Consumos
            </span>
            <span className="material-symbols-outlined text-[#000000] text-[22px]">
              inventory_2
            </span>
          </div>
          <div className="text-[36px] font-bold text-[#191c1e] mb-2 leading-tight">
            892
          </div>
          <div className="flex items-center gap-1">
            <span className="material-symbols-outlined text-[#ba1a1a] text-sm">
              trending_down
            </span>
            <span className="font-semibold text-sm text-[#ba1a1a]">-4.2%</span>
            <span className="text-[12px] text-[#45464d] ml-2">vs last month</span>
          </div>
        </div>
      </div>

      {/* Simplified Charts for Mobile */}
      <div
        id="mobile-weekly-trend-card"
        className="bg-white rounded-lg border border-[#c6c6cd] p-4 shadow-2xs"
      >
        <WeeklyTrendChart />
      </div>

      {/* Recent Activity List */}
      <div
        id="mobile-recent-transactions-card"
        className="bg-white rounded-lg border border-[#c6c6cd] shadow-2xs overflow-hidden"
      >
        <div className="px-4 py-2.5 border-b border-[#c6c6cd] bg-[#F1F5F9]">
          <h3 className="text-[12px] font-semibold text-[#191c1e] uppercase tracking-wider">
            Recent Transactions
          </h3>
        </div>

        <div className="divide-y divide-[#c6c6cd]">
          {transactions.slice(0, 4).map((trx) => {
            const isEntrega = trx.type === 'Entrega';
            return (
              <div
                key={trx.id}
                onClick={() => onSelectTransaction?.(trx)}
                className="p-4 flex justify-between items-center hover:bg-[#F8FAFC] transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded bg-[#E2E8F0] flex items-center justify-center text-[#000000] shrink-0">
                    <span className="material-symbols-outlined text-[20px]">
                      {isEntrega ? 'outbox' : 'move_to_inbox'}
                    </span>
                  </div>
                  <div>
                    <p className="font-mono text-[14px] font-bold text-[#191c1e]">{trx.id}</p>
                    <p className="text-[13px] text-[#45464d]">
                      {trx.type} - {trx.destination}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-mono text-[14px] text-[#191c1e] font-bold">
                    {isEntrega ? `+${trx.units}` : `-${trx.units}`} units
                  </p>
                  <span
                    className={`inline-block px-2 py-0.5 rounded text-[10px] font-semibold mt-1 ${
                      trx.status === 'Completed'
                        ? 'bg-[#DCFCE7] text-[#166534]'
                        : trx.status === 'Pending'
                        ? 'bg-[#FEF9C3] text-[#854D0E]'
                        : 'bg-[#FEE2E2] text-[#991B1B]'
                    }`}
                  >
                    {trx.status}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        <div className="p-2.5 text-center border-t border-[#c6c6cd] bg-[#f7f9fb]">
          <button
            onClick={onViewAllTransactions}
            className="text-[12px] font-medium text-[#000000] hover:underline cursor-pointer"
          >
            View All Activity
          </button>
        </div>
      </div>
    </div>
  );
};
