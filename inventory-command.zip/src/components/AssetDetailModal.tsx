import React from 'react';
import { Asset, AssetStatus } from '../types';

interface AssetDetailModalProps {
  asset: Asset | null;
  onClose: () => void;
  onUpdateStatus: (assetId: string, newStatus: AssetStatus) => void;
  onDeleteAsset: (assetId: string) => void;
}

export const AssetDetailModal: React.FC<AssetDetailModalProps> = ({
  asset,
  onClose,
  onUpdateStatus,
  onDeleteAsset,
}) => {
  if (!asset) return null;

  const statusBadge = (status: AssetStatus) => {
    switch (status) {
      case 'Active':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-[#dcfce7] text-[#166534] border border-[#bbf7d0]">
            Active
          </span>
        );
      case 'Maintenance':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-[#fef08a] text-[#854d0e] border border-[#fde047]">
            Maintenance
          </span>
        );
      case 'Retired':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-[#fee2e2] text-[#991b1b] border border-[#fecaca]">
            Retired
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-[#e0e3e5] text-[#45464d]">
            {status}
          </span>
        );
    }
  };

  return (
    <div
      id="asset-detail-backdrop"
      className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4 backdrop-blur-xs animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        id="asset-detail-modal"
        className="bg-white rounded border border-[#c6c6cd] shadow-xl w-full max-w-lg overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-[#f2f4f6] px-6 py-4 border-b border-[#c6c6cd] flex justify-between items-center">
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-[16px] font-bold text-[#191c1e]">
                {asset.id}
              </span>
              {statusBadge(asset.status)}
            </div>
            <p className="text-[13px] text-[#45464d]">{asset.type} • {asset.category}</p>
          </div>
          <button
            onClick={onClose}
            className="text-[#45464d] hover:text-[#191c1e] p-1 rounded hover:bg-[#e0e3e5] cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          {/* Health Score Banner */}
          <div className="p-4 bg-[#f7f9fb] border border-[#c6c6cd] rounded flex items-center justify-between">
            <div>
              <span className="text-[11px] font-semibold tracking-wider text-[#45464d] uppercase">
                Device Telemetry & Health
              </span>
              <div className="text-[20px] font-bold text-[#191c1e] mt-0.5">
                {asset.healthScore ?? 95}% Operational
              </div>
            </div>
            <div className="w-12 h-12 rounded-full border-4 border-[#0F172A] flex items-center justify-center font-bold text-[13px]">
              {asset.healthScore ?? 95}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 text-[13px]">
            <div>
              <span className="text-[#45464d] text-[11px] uppercase tracking-wider block">Ubicación</span>
              <span className="font-medium text-[#191c1e]">{asset.location}</span>
            </div>
            <div>
              <span className="text-[#45464d] text-[11px] uppercase tracking-wider block">Región</span>
              <span className="font-medium text-[#191c1e]">{asset.region}</span>
            </div>
            <div>
              <span className="text-[#45464d] text-[11px] uppercase tracking-wider block">Gerencia</span>
              <span className="font-medium text-[#191c1e]">{asset.department}</span>
            </div>
            <div>
              <span className="text-[#45464d] text-[11px] uppercase tracking-wider block">Asignado a</span>
              <span className="font-medium text-[#191c1e]">{asset.assignedTo || 'Depósito Central'}</span>
            </div>
            <div>
              <span className="text-[#45464d] text-[11px] uppercase tracking-wider block">Fecha de Despliegue</span>
              <span className="font-medium text-[#191c1e]">{asset.deploymentDate}</span>
            </div>
            <div>
              <span className="text-[#45464d] text-[11px] uppercase tracking-wider block">Último Mantenimiento</span>
              <span className="font-medium text-[#191c1e]">{asset.lastMaintenance || 'N/A'}</span>
            </div>
            <div>
              <span className="text-[#45464d] text-[11px] uppercase tracking-wider block">Número de Serie</span>
              <span className="font-mono text-[12px] font-medium text-[#191c1e]">{asset.serialNumber}</span>
            </div>
            <div>
              <span className="text-[#45464d] text-[11px] uppercase tracking-wider block">Valor de Activo</span>
              <span className="font-medium text-[#191c1e]">${asset.cost?.toLocaleString() || '3,500'} USD</span>
            </div>
          </div>

          {/* Quick status change */}
          <div className="pt-2 border-t border-[#c6c6cd]">
            <label className="text-[12px] font-medium text-[#45464d] block mb-1.5">
              Cambiar Estado de Operación
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['Active', 'Maintenance', 'Retired'] as AssetStatus[]).map((st) => (
                <button
                  key={st}
                  onClick={() => onUpdateStatus(asset.id, st)}
                  className={`py-1.5 px-3 text-xs font-medium rounded border transition-all cursor-pointer ${
                    asset.status === st
                      ? 'bg-[#000000] text-white border-[#000000]'
                      : 'bg-white text-[#191c1e] border-[#c6c6cd] hover:bg-[#f2f4f6]'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-[#f2f4f6] px-6 py-3 border-t border-[#c6c6cd] flex justify-between items-center">
          <button
            onClick={() => {
              if (confirm(`¿Dar de baja o eliminar el activo ${asset.id}?`)) {
                onDeleteAsset(asset.id);
                onClose();
              }
            }}
            className="text-[12px] text-[#ba1a1a] hover:underline flex items-center gap-1 cursor-pointer font-medium"
          >
            <span className="material-symbols-outlined text-[16px]">delete</span>
            Eliminar activo
          </button>

          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-[#000000] text-white rounded-[2px] text-[12px] font-medium hover:bg-[#131b2e] cursor-pointer"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};
