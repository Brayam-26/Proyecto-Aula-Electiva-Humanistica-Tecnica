import React, { useState } from 'react';

interface SettingsSupportModalProps {
  initialTab?: 'settings' | 'support';
  onClose: () => void;
}

export const SettingsSupportModal: React.FC<SettingsSupportModalProps> = ({
  initialTab = 'settings',
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'settings' | 'support'>(initialTab);
  const [ticketSubject, setTicketSubject] = useState('');
  const [ticketDesc, setTicketDesc] = useState('');
  const [ticketSubmitted, setTicketSubmitted] = useState(false);

  const handleTicketSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setTicketSubmitted(true);
    setTimeout(() => {
      setTicketSubmitted(false);
      setTicketSubject('');
      setTicketDesc('');
      onClose();
    }, 2000);
  };

  return (
    <div
      className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4 backdrop-blur-xs"
      onClick={onClose}
    >
      <div
        className="bg-white rounded border border-[#c6c6cd] shadow-2xl w-full max-w-lg overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-[#f2f4f6] px-6 py-4 border-b border-[#c6c6cd] flex justify-between items-center">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('settings')}
              className={`text-[14px] font-bold pb-0.5 border-b-2 transition-colors cursor-pointer ${
                activeTab === 'settings'
                  ? 'text-[#000000] border-[#000000]'
                  : 'text-[#45464d] border-transparent hover:text-[#191c1e]'
              }`}
            >
              System Settings
            </button>
            <span className="text-[#c6c6cd]">|</span>
            <button
              onClick={() => setActiveTab('support')}
              className={`text-[14px] font-bold pb-0.5 border-b-2 transition-colors cursor-pointer ${
                activeTab === 'support'
                  ? 'text-[#000000] border-[#000000]'
                  : 'text-[#45464d] border-transparent hover:text-[#191c1e]'
              }`}
            >
              Enterprise Support
            </button>
          </div>
          <button
            onClick={onClose}
            className="text-[#45464d] hover:text-[#191c1e] p-1 rounded"
          >
            ✕
          </button>
        </div>

        {/* Body */}
        <div className="p-6 max-h-[70vh] overflow-y-auto">
          {activeTab === 'settings' ? (
            <div className="space-y-4 text-[13px]">
              <div>
                <h3 className="font-semibold text-[#191c1e] mb-1">Organización y Licencia</h3>
                <div className="p-3 bg-[#f7f9fb] border border-[#c6c6cd] rounded">
                  <p className="font-medium text-[#191c1e]">Global Supply Corporation</p>
                  <p className="text-[12px] text-[#45464d]">Plan: Enterprise Tier (Multi-Region 99.99% SLA)</p>
                  <p className="text-[12px] text-[#45464d]">Versión del Dashboard: v2.8.4 Enterprise Release</p>
                </div>
              </div>

              <div>
                <h3 className="font-semibold text-[#191c1e] mb-1">Parámetros de Auditoría y Alertas</h3>
                <div className="space-y-2">
                  <label className="flex items-center justify-between p-2.5 bg-[#f7f9fb] border border-[#c6c6cd] rounded cursor-pointer">
                    <span>Notificar automáticamente en entregas críticas</span>
                    <input type="checkbox" defaultChecked className="accent-[#000000]" />
                  </label>
                  <label className="flex items-center justify-between p-2.5 bg-[#f7f9fb] border border-[#c6c6cd] rounded cursor-pointer">
                    <span>Alerta temprana si el stock disminuye &gt; 15% semanal</span>
                    <input type="checkbox" defaultChecked className="accent-[#000000]" />
                  </label>
                  <label className="flex items-center justify-between p-2.5 bg-[#f7f9fb] border border-[#c6c6cd] rounded cursor-pointer">
                    <span>Generar bitácora inmutable en cada modificación de activo</span>
                    <input type="checkbox" defaultChecked className="accent-[#000000]" />
                  </label>
                </div>
              </div>

              <div>
                <h3 className="font-semibold text-[#191c1e] mb-1">Idioma y Formato Regional</h3>
                <select className="w-full bg-[#f7f9fb] border border-[#c6c6cd] rounded p-2">
                  <option>Español (Latinoamérica) - USD</option>
                  <option>English (United States) - USD</option>
                  <option>Deutsch (Deutschland) - EUR</option>
                </select>
              </div>
            </div>
          ) : (
            <div className="space-y-4 text-[13px]">
              <div className="p-3 bg-[#e0f2fe] border border-[#bae6fd] rounded text-[#0369a1]">
                <p className="font-semibold flex items-center gap-1">
                  <span className="material-symbols-outlined text-[18px]">verified</span>
                  Soporte Dedicado 24/7 - Enterprise Tier
                </p>
                <p className="text-[12px] mt-0.5">
                  Tiempo de respuesta garantizado: menos de 15 minutos para incidentes críticos.
                </p>
              </div>

              {ticketSubmitted ? (
                <div className="p-6 text-center text-[#166534] bg-[#dcfce7] border border-[#bbf7d0] rounded">
                  <span className="material-symbols-outlined text-3xl mb-1">check_circle</span>
                  <p className="font-bold">Ticket de soporte generado exitosamente</p>
                  <p className="text-xs text-[#166534] mt-1">Un ingeniero en operaciones responderá a la brevedad.</p>
                </div>
              ) : (
                <form onSubmit={handleTicketSubmit} className="space-y-3">
                  <div>
                    <label className="text-[12px] font-medium text-[#45464d] block mb-1">
                      Asunto de la solicitud
                    </label>
                    <input
                      type="text"
                      value={ticketSubject}
                      onChange={(e) => setTicketSubject(e.target.value)}
                      placeholder="ej. Reemplazo de hardware en Data Center Alpha"
                      className="w-full bg-[#f7f9fb] border border-[#c6c6cd] rounded px-3 py-1.5"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-[12px] font-medium text-[#45464d] block mb-1">
                      Detalle técnico / Incidencia
                    </label>
                    <textarea
                      rows={4}
                      value={ticketDesc}
                      onChange={(e) => setTicketDesc(e.target.value)}
                      placeholder="Describa el código de activo, anomalía o requerimiento logístico..."
                      className="w-full bg-[#f7f9fb] border border-[#c6c6cd] rounded px-3 py-1.5"
                      required
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full py-2 bg-[#000000] text-white rounded text-[13px] font-medium hover:bg-[#131b2e] cursor-pointer"
                  >
                    Enviar Solicitud al Centro de Operaciones
                  </button>
                </form>
              )}
            </div>
          )}
        </div>

        <div className="bg-[#f2f4f6] px-6 py-3 border-t border-[#c6c6cd] flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-[#000000] text-white rounded text-[12px] font-medium hover:bg-[#131b2e] cursor-pointer"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};
