import React from 'react';
import { USER_AVATAR_URL } from '../data/mockData';

interface TopHeaderProps {
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onToggleMobileMenu: () => void;
  onToggleNotifications: () => void;
  onOpenSettings: () => void;
  unreadAlertsCount: number;
  viewMode: 'desktop' | 'mobile' | 'responsive';
  onChangeViewMode: (mode: 'desktop' | 'mobile' | 'responsive') => void;
}

export const TopHeader: React.FC<TopHeaderProps> = ({
  searchQuery,
  onSearchChange,
  onToggleMobileMenu,
  onToggleNotifications,
  onOpenSettings,
  unreadAlertsCount,
  viewMode,
  onChangeViewMode,
}) => {
  return (
    <header
      id="top-navbar"
      className="bg-white border-b border-[#c6c6cd] flex justify-between items-center w-full px-6 h-16 sticky top-0 z-30"
    >
      {/* Left title & mobile trigger */}
      <div className="flex items-center gap-3">
        <button
          id="mobile-hamburger-btn"
          onClick={onToggleMobileMenu}
          className="md:hidden p-1 text-[#191c1e] hover:bg-[#f2f4f6] rounded cursor-pointer"
          aria-label="Abrir menú"
        >
          <span className="material-symbols-outlined text-[24px]">menu</span>
        </button>

        <span className="text-[20px] md:text-[28px] font-bold text-[#000000] tracking-tight">
          Inventory Command
        </span>
      </div>

      {/* Right actions */}
      <div className="flex items-center gap-3 md:gap-4">
        {/* Device View Mode Switcher (helpful to easily test Image 2 vs Image 4) */}
        <div className="hidden lg:flex items-center bg-[#f2f4f6] p-0.5 rounded border border-[#c6c6cd] text-[11px] font-medium text-[#45464d]">
          <button
            id="viewmode-responsive"
            onClick={() => onChangeViewMode('responsive')}
            className={`px-2 py-1 rounded transition-colors ${
              viewMode === 'responsive'
                ? 'bg-white text-[#191c1e] shadow-xs font-semibold'
                : 'hover:text-[#191c1e]'
            }`}
            title="Vista adaptable"
          >
            Auto
          </button>
          <button
            id="viewmode-desktop"
            onClick={() => onChangeViewMode('desktop')}
            className={`px-2 py-1 rounded transition-colors flex items-center gap-1 ${
              viewMode === 'desktop'
                ? 'bg-white text-[#191c1e] shadow-xs font-semibold'
                : 'hover:text-[#191c1e]'
            }`}
            title="Vista de escritorio (Imagen 2)"
          >
            <span className="material-symbols-outlined text-[14px]">desktop_windows</span>
            Desktop
          </button>
          <button
            id="viewmode-mobile"
            onClick={() => onChangeViewMode('mobile')}
            className={`px-2 py-1 rounded transition-colors flex items-center gap-1 ${
              viewMode === 'mobile'
                ? 'bg-white text-[#191c1e] shadow-xs font-semibold'
                : 'hover:text-[#191c1e]'
            }`}
            title="Vista móvil (Imagen 4)"
          >
            <span className="material-symbols-outlined text-[14px]">smartphone</span>
            Móvil
          </button>
        </div>

        {/* Search Input */}
        <div className="relative hidden sm:block w-52 md:w-64">
          <span className="material-symbols-outlined absolute left-2.5 top-1/2 -translate-y-1/2 text-[#45464d] text-[18px]">
            search
          </span>
          <input
            id="top-search-input"
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search resources..."
            className="w-full bg-[#f7f9fb] border border-[#c6c6cd] rounded-[2px] pl-[32px] pr-2.5 py-1 text-[14px] text-[#191c1e] focus:outline-none focus:border-[#000000] focus:ring-1 focus:ring-[#000000] transition-colors h-8"
          />
          {searchQuery && (
            <button
              onClick={() => onSearchChange('')}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-[#76777d] hover:text-[#191c1e] text-xs"
            >
              ✕
            </button>
          )}
        </div>

        {/* Action icons */}
        <div className="flex items-center gap-1 sm:gap-2">
          <button
            id="top-notifications-btn"
            onClick={onToggleNotifications}
            className="relative p-1.5 text-[#45464d] hover:bg-[#e6e8ea] transition-colors rounded-full cursor-pointer"
            aria-label="Alertas y Notificaciones"
          >
            <span className="material-symbols-outlined text-[20px]">notifications</span>
            {unreadAlertsCount > 0 && (
              <span className="absolute top-1 right-1 w-2 h-2 bg-[#ba1a1a] rounded-full ring-2 ring-white"></span>
            )}
          </button>
          <button
            id="top-settings-btn"
            onClick={onOpenSettings}
            className="p-1.5 text-[#45464d] hover:bg-[#e6e8ea] transition-colors rounded-full cursor-pointer"
            aria-label="Configuración"
          >
            <span className="material-symbols-outlined text-[20px]">settings</span>
          </button>
        </div>

        {/* Profile Image */}
        <div
          id="user-profile-avatar"
          onClick={onOpenSettings}
          className="w-8 h-8 rounded-full overflow-hidden border border-[#c6c6cd] cursor-pointer hover:ring-2 hover:ring-[#000000] transition-all ml-1"
          title="Global Operations Administrator"
        >
          <img
            alt="User profile"
            className="w-full h-full object-cover"
            src={USER_AVATAR_URL}
          />
        </div>
      </div>
    </header>
  );
};
