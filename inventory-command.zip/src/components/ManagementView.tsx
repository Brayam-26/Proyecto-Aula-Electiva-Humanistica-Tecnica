import React, { useState } from 'react';
import { Asset, AssetStatus } from '../types';

interface ManagementViewProps {
  assets: Asset[];
  onSelectAsset: (asset: Asset) => void;
  onOpenNewAssetModal: () => void;
  onOpenExport: () => void;
  onUpdateStatus: (assetId: string, status: AssetStatus) => void;
}

export const ManagementView: React.FC<ManagementViewProps> = ({
  assets,
  onSelectAsset,
  onOpenNewAssetModal,
  onOpenExport,
  onUpdateStatus,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');
  const [departmentFilter, setDepartmentFilter] = useState('All');

  const filteredAssets = assets.filter((asset) => {
    if (categoryFilter !== 'All' && asset.category !== categoryFilter) return false;
    if (statusFilter !== 'All' && asset.status !== statusFilter) return false;
    if (departmentFilter !== 'All' && asset.department !== departmentFilter) return false;
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      return (
        asset.id.toLowerCase().includes(q) ||
        asset.type.toLowerCase().includes(q) ||
        asset.location.toLowerCase().includes(q) ||
        asset.serialNumber.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const totalValue = filteredAssets.reduce((sum, a) => sum + (a.cost || 0), 0);
  const activeCount = filteredAssets.filter((a) => a.status === 'Active').length;
  const maintenanceCount = filteredAssets.filter((a) => a.status === 'Maintenance').length;
  const retiredCount = filteredAssets.filter((a) => a.status === 'Retired').length;

  return (
    <div className="p-6 md:p-10 max-w-[1440px] mx-auto w-full space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end pb-4 border-b border-[#c6c6cd] gap-4">
        <div>
          <h2 className="text-[24px] font-semibold text-[#191c1e] tracking-tight">
            Inventory & Asset Management
          </h2>
          <p className="text-[14px] text-[#45464d] mt-1">
            Control integral del ciclo de vida, asignaciones y estado operativo de hardware corporativo.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onOpenExport}
            className="px-3 py-1.5 border border-[#76777d] rounded text-[12px] font-medium text-[#191c1e] hover:bg-[#e6e8ea] transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">file_download</span>
            Exportar
          </button>
          <button
            onClick={onOpenNewAssetModal}
            className="px-4 py-1.5 bg-[#000000] text-white rounded text-[12px] font-medium hover:bg-[#131b2e] transition-colors flex items-center gap-1.5 cursor-pointer shadow-sm"
          >
            <span className="material-symbols-outlined text-[16px]">add</span>
            Nuevo Activo
          </button>
        </div>
      </div>

      {/* Mini Stats Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white border border-[#c6c6cd] p-4 rounded-[2px]">
          <span className="text-[11px] font-medium text-[#45464d] uppercase tracking-wider block">
            Total Activos Filtrados
          </span>
          <span className="text-[24px] font-bold text-[#191c1e]">{filteredAssets.length}</span>
        </div>
        <div className="bg-white border border-[#c6c6cd] p-4 rounded-[2px]">
          <span className="text-[11px] font-medium text-[#45464d] uppercase tracking-wider block">
            Valor de Inventario
          </span>
          <span className="text-[24px] font-bold text-[#191c1e]">${totalValue.toLocaleString()} USD</span>
        </div>
        <div className="bg-white border border-[#c6c6cd] p-4 rounded-[2px]">
          <span className="text-[11px] font-medium text-[#45464d] uppercase tracking-wider block">
            En Mantenimiento
          </span>
          <span className="text-[24px] font-bold text-[#854d0e]">{maintenanceCount}</span>
        </div>
        <div className="bg-white border border-[#c6c6cd] p-4 rounded-[2px]">
          <span className="text-[11px] font-medium text-[#45464d] uppercase tracking-wider block">
            Activos / Retirados
          </span>
          <span className="text-[24px] font-bold text-[#166534]">
            {activeCount} <span className="text-xs text-[#76777d]">/ {retiredCount}</span>
          </span>
        </div>
      </div>

      {/* Filters & Search Toolbar */}
      <div className="bg-white border border-[#c6c6cd] p-4 rounded-[2px] flex flex-wrap items-center justify-between gap-4">
        <div className="relative w-full sm:w-72">
          <span className="material-symbols-outlined absolute left-2.5 top-1/2 -translate-y-1/2 text-[#45464d] text-[18px]">
            search
          </span>
          <input
            type="text"
            placeholder="Buscar por ID, modelo, serie o sede..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-[#f7f9fb] border border-[#c6c6cd] rounded pl-9 pr-3 py-1.5 text-[13px] text-[#191c1e] focus:border-[#000000] focus:outline-none"
          />
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Categoría */}
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="bg-[#f7f9fb] border border-[#c6c6cd] rounded px-2.5 py-1.5 text-[13px] text-[#191c1e] focus:border-[#000000] cursor-pointer"
          >
            <option value="All">Todas las Categorías</option>
            <option value="Computing">Computing</option>
            <option value="Networking">Networking</option>
            <option value="Storage">Storage</option>
            <option value="Peripherals">Peripherals</option>
            <option value="Mobile Devices">Mobile Devices</option>
            <option value="Displays">Displays</option>
          </select>

          {/* Estado */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-[#f7f9fb] border border-[#c6c6cd] rounded px-2.5 py-1.5 text-[13px] text-[#191c1e] focus:border-[#000000] cursor-pointer"
          >
            <option value="All">Todos los Estados</option>
            <option value="Active">Active</option>
            <option value="Maintenance">Maintenance</option>
            <option value="Retired">Retired</option>
          </select>

          {/* Gerencia */}
          <select
            value={departmentFilter}
            onChange={(e) => setDepartmentFilter(e.target.value)}
            className="bg-[#f7f9fb] border border-[#c6c6cd] rounded px-2.5 py-1.5 text-[13px] text-[#191c1e] focus:border-[#000000] cursor-pointer"
          >
            <option value="All">Todas las Gerencias</option>
            <option value="IT Infrastructure">IT Infrastructure</option>
            <option value="Logistics">Logistics</option>
            <option value="Facilities">Facilities</option>
            <option value="Engineering">Engineering</option>
          </select>

          {(searchTerm || categoryFilter !== 'All' || statusFilter !== 'All' || departmentFilter !== 'All') && (
            <button
              onClick={() => {
                setSearchTerm('');
                setCategoryFilter('All');
                setStatusFilter('All');
                setDepartmentFilter('All');
              }}
              className="text-[12px] text-[#ba1a1a] hover:underline cursor-pointer"
            >
              Limpiar filtros
            </button>
          )}
        </div>
      </div>

      {/* Main Assets Table */}
      <div className="bg-white border border-[#c6c6cd] rounded-[2px] overflow-hidden shadow-2xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse zebra-stripes">
            <thead>
              <tr className="bg-[#eceef0] text-[#191c1e] text-[12px] font-medium border-b border-[#c6c6cd] tracking-wide">
                <th className="p-4 font-semibold">Asset ID</th>
                <th className="p-4 font-semibold">Equipo / Tipo</th>
                <th className="p-4 font-semibold">Categoría</th>
                <th className="p-4 font-semibold">Ubicación Físca</th>
                <th className="p-4 font-semibold">Gerencia</th>
                <th className="p-4 font-semibold">Estado Operativo</th>
                <th className="p-4 font-semibold">Salud (%)</th>
                <th className="p-4 font-semibold text-right">Acción</th>
              </tr>
            </thead>
            <tbody className="text-[13px] text-[#191c1e]">
              {filteredAssets.map((asset) => (
                <tr
                  key={asset.id}
                  className="border-b border-[#c6c6cd] hover:bg-[#f2f4f6] transition-colors"
                >
                  <td className="p-4 font-mono font-bold text-[#191c1e]">{asset.id}</td>
                  <td className="p-4">
                    <div className="font-semibold text-[#191c1e]">{asset.type}</div>
                    <div className="text-[11px] text-[#45464d] font-mono">SN: {asset.serialNumber}</div>
                  </td>
                  <td className="p-4 text-[#45464d]">{asset.category}</td>
                  <td className="p-4">
                    <span className="text-[#191c1e] font-medium">{asset.location}</span>
                    <span className="text-[11px] text-[#76777d] block">{asset.region}</span>
                  </td>
                  <td className="p-4 text-[#45464d]">{asset.department}</td>
                  <td className="p-4">
                    <select
                      value={asset.status}
                      onChange={(e) => onUpdateStatus(asset.id, e.target.value as AssetStatus)}
                      className={`text-xs font-semibold px-2 py-1 rounded border cursor-pointer ${
                        asset.status === 'Active'
                          ? 'bg-[#dcfce7] text-[#166534] border-[#bbf7d0]'
                          : asset.status === 'Maintenance'
                          ? 'bg-[#fef08a] text-[#854d0e] border-[#fde047]'
                          : 'bg-[#fee2e2] text-[#991b1b] border-[#fecaca]'
                      }`}
                    >
                      <option value="Active">Active</option>
                      <option value="Maintenance">Maintenance</option>
                      <option value="Retired">Retired</option>
                    </select>
                  </td>
                  <td className="p-4">
                    <div className="flex items-center gap-2">
                      <div className="w-16 bg-[#e0e3e5] h-2 rounded-full overflow-hidden">
                        <div
                          className={`h-full ${
                            (asset.healthScore ?? 90) > 80
                              ? 'bg-[#16a34a]'
                              : (asset.healthScore ?? 90) > 50
                              ? 'bg-[#eab308]'
                              : 'bg-[#dc2626]'
                          }`}
                          style={{ width: `${asset.healthScore ?? 90}%` }}
                        />
                      </div>
                      <span className="text-[11px] font-mono font-medium">
                        {asset.healthScore ?? 90}%
                      </span>
                    </div>
                  </td>
                  <td className="p-4 text-right">
                    <button
                      onClick={() => onSelectAsset(asset)}
                      className="text-[#000000] font-semibold hover:underline cursor-pointer py-1 px-2.5 rounded hover:bg-[#e0e3e5]"
                    >
                      Detalles
                    </button>
                  </td>
                </tr>
              ))}
              {filteredAssets.length === 0 && (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-[#45464d]">
                    No se encontraron activos que coincidan con los criterios.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
