import React, { useState } from 'react';
import { Transaction } from '../types';

interface ReportsViewProps {
  transactions: Transaction[];
  onAddTransaction: (trx: Transaction) => void;
  onOpenExport: () => void;
}

export const ReportsView: React.FC<ReportsViewProps> = ({
  transactions,
  onAddTransaction,
  onOpenExport,
}) => {
  const [filterType, setFilterType] = useState<'All' | 'Entrega' | 'Consumo'>('All');
  const [showNewTrxModal, setShowNewTrxModal] = useState(false);
  const [newTrxData, setNewTrxData] = useState({
    type: 'Entrega' as 'Entrega' | 'Consumo',
    destination: 'Hub Central',
    units: 50,
    operator: 'Operador en Turno',
  });

  const filteredTransactions = transactions.filter((t) => {
    if (filterType !== 'All' && t.type !== filterType) return false;
    return true;
  });

  const handleCreateTrx = (e: React.FormEvent) => {
    e.preventDefault();
    const newTrx: Transaction = {
      id: `TRX-${Math.floor(9000 + Math.random() * 999)}`,
      type: newTrxData.type,
      destination: newTrxData.destination,
      units: Number(newTrxData.units),
      status: 'Completed',
      date: new Date().toISOString().slice(0, 10),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      operator: newTrxData.operator,
      assetCategory: 'Computing',
    };
    onAddTransaction(newTrx);
    setShowNewTrxModal(false);
  };

  return (
    <div className="p-6 md:p-10 max-w-[1440px] mx-auto w-full space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end pb-4 border-b border-[#c6c6cd] gap-4">
        <div>
          <h2 className="text-[24px] font-semibold text-[#191c1e] tracking-tight">
            Transaction Logs & Audit Reports
          </h2>
          <p className="text-[14px] text-[#45464d] mt-1">
            Registro inmutable de movimientos de stock, entregas y consumos para auditoría corporativa.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onOpenExport}
            className="px-3 py-1.5 border border-[#76777d] rounded text-[12px] font-medium text-[#191c1e] hover:bg-[#e6e8ea] flex items-center gap-1.5 cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">print</span>
            Descargar Reporte
          </button>
          <button
            onClick={() => setShowNewTrxModal(true)}
            className="px-4 py-1.5 bg-[#000000] text-white rounded text-[12px] font-medium hover:bg-[#131b2e] flex items-center gap-1.5 cursor-pointer shadow-sm"
          >
            <span className="material-symbols-outlined text-[16px]">sync_alt</span>
            Registrar Movimiento
          </button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center justify-between bg-white border border-[#c6c6cd] p-3 rounded-[2px]">
        <div className="flex items-center gap-2">
          {(['All', 'Entrega', 'Consumo'] as const).map((type) => (
            <button
              key={type}
              onClick={() => setFilterType(type)}
              className={`px-3 py-1 text-xs font-semibold rounded transition-colors cursor-pointer ${
                filterType === type
                  ? 'bg-[#000000] text-white'
                  : 'bg-[#f7f9fb] text-[#45464d] hover:text-[#191c1e]'
              }`}
            >
              {type === 'All' ? 'Todos los Movimientos' : `${type}s`}
            </button>
          ))}
        </div>

        <span className="text-[12px] text-[#45464d] font-medium">
          Mostrando {filteredTransactions.length} registros auditados
        </span>
      </div>

      {/* Transaction Table */}
      <div className="bg-white border border-[#c6c6cd] rounded-[2px] overflow-hidden shadow-2xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse zebra-stripes">
            <thead>
              <tr className="bg-[#eceef0] text-[#191c1e] text-[12px] font-medium border-b border-[#c6c6cd]">
                <th className="p-4 font-semibold">Código TRX</th>
                <th className="p-4 font-semibold">Tipo de Movimiento</th>
                <th className="p-4 font-semibold">Destino / Hub</th>
                <th className="p-4 font-semibold">Unidades</th>
                <th className="p-4 font-semibold">Operador Responsable</th>
                <th className="p-4 font-semibold">Fecha y Hora</th>
                <th className="p-4 font-semibold text-right">Estado</th>
              </tr>
            </thead>
            <tbody className="text-[13px] text-[#191c1e]">
              {filteredTransactions.map((trx) => {
                const isEntrega = trx.type === 'Entrega';
                return (
                  <tr key={trx.id} className="border-b border-[#c6c6cd] hover:bg-[#f2f4f6]">
                    <td className="p-4 font-mono font-bold text-[#191c1e]">{trx.id}</td>
                    <td className="p-4">
                      <div className="flex items-center gap-2 font-medium">
                        <span className="material-symbols-outlined text-[18px] text-[#45464d]">
                          {isEntrega ? 'outbox' : 'move_to_inbox'}
                        </span>
                        <span>{trx.type}</span>
                      </div>
                    </td>
                    <td className="p-4 text-[#45464d]">{trx.destination}</td>
                    <td className="p-4">
                      <span
                        className={`font-mono font-bold ${
                          isEntrega ? 'text-[#16a34a]' : 'text-[#ba1a1a]'
                        }`}
                      >
                        {isEntrega ? `+${trx.units}` : `-${trx.units}`} uds
                      </span>
                    </td>
                    <td className="p-4 text-[#45464d]">{trx.operator}</td>
                    <td className="p-4 text-[#45464d]">
                      {trx.date} <span className="text-xs text-[#76777d]">({trx.time})</span>
                    </td>
                    <td className="p-4 text-right">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded text-[11px] font-semibold ${
                          trx.status === 'Completed'
                            ? 'bg-[#DCFCE7] text-[#166534]'
                            : trx.status === 'Pending'
                            ? 'bg-[#FEF9C3] text-[#854D0E]'
                            : 'bg-[#FEE2E2] text-[#991B1B]'
                        }`}
                      >
                        {trx.status}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* New Transaction Modal */}
      {showNewTrxModal && (
        <div
          className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4 backdrop-blur-xs"
          onClick={() => setShowNewTrxModal(false)}
        >
          <div
            className="bg-white rounded border border-[#c6c6cd] shadow-xl w-full max-w-md overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="bg-[#f2f4f6] px-5 py-4 border-b border-[#c6c6cd] flex justify-between items-center">
              <h3 className="font-bold text-[16px] text-[#191c1e]">Registrar Entrega o Consumo</h3>
              <button
                onClick={() => setShowNewTrxModal(false)}
                className="text-[#45464d] hover:text-[#191c1e]"
              >
                ✕
              </button>
            </div>
            <form onSubmit={handleCreateTrx} className="p-5 space-y-4 text-[13px]">
              <div>
                <label className="text-[12px] font-medium text-[#45464d] block mb-1">
                  Tipo de Operación
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setNewTrxData({ ...newTrxData, type: 'Entrega' })}
                    className={`py-2 rounded font-semibold border cursor-pointer ${
                      newTrxData.type === 'Entrega'
                        ? 'bg-[#000000] text-white border-[#000000]'
                        : 'bg-white border-[#c6c6cd] text-[#191c1e]'
                    }`}
                  >
                    Entrega (Ingreso)
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewTrxData({ ...newTrxData, type: 'Consumo' })}
                    className={`py-2 rounded font-semibold border cursor-pointer ${
                      newTrxData.type === 'Consumo'
                        ? 'bg-[#000000] text-white border-[#000000]'
                        : 'bg-white border-[#c6c6cd] text-[#191c1e]'
                    }`}
                  >
                    Consumo (Salida)
                  </button>
                </div>
              </div>

              <div>
                <label className="text-[12px] font-medium text-[#45464d] block mb-1">
                  Hub / Destino
                </label>
                <input
                  type="text"
                  value={newTrxData.destination}
                  onChange={(e) =>
                    setNewTrxData({ ...newTrxData, destination: e.target.value })
                  }
                  className="w-full bg-[#f7f9fb] border border-[#c6c6cd] rounded px-3 py-1.5"
                  required
                />
              </div>

              <div>
                <label className="text-[12px] font-medium text-[#45464d] block mb-1">
                  Cantidad de Unidades
                </label>
                <input
                  type="number"
                  min="1"
                  value={newTrxData.units}
                  onChange={(e) =>
                    setNewTrxData({ ...newTrxData, units: Number(e.target.value) })
                  }
                  className="w-full bg-[#f7f9fb] border border-[#c6c6cd] rounded px-3 py-1.5 font-mono"
                  required
                />
              </div>

              <div>
                <label className="text-[12px] font-medium text-[#45464d] block mb-1">
                  Operador Autorizado
                </label>
                <input
                  type="text"
                  value={newTrxData.operator}
                  onChange={(e) =>
                    setNewTrxData({ ...newTrxData, operator: e.target.value })
                  }
                  className="w-full bg-[#f7f9fb] border border-[#c6c6cd] rounded px-3 py-1.5"
                  required
                />
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-[#c6c6cd]">
                <button
                  type="button"
                  onClick={() => setShowNewTrxModal(false)}
                  className="px-3 py-1.5 border border-[#c6c6cd] rounded text-[12px]"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-[#000000] text-white rounded text-[12px] font-semibold"
                >
                  Confirmar Registro
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
