import React from 'react';

interface NotificationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  alerts: { id: string; title: string; desc: string; severity: 'critical' | 'warning' | 'info'; time: string }[];
  onDismissAlert: (id: string) => void;
}

export const NotificationDrawer: React.FC<NotificationDrawerProps> = ({
  isOpen,
  onClose,
  alerts,
  onDismissAlert,
}) => {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 bg-black/40 z-50 flex justify-end backdrop-blur-xs"
      onClick={onClose}
    >
      <div
        className="w-full max-w-sm bg-white h-full border-l border-[#c6c6cd] shadow-2xl flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="bg-[#f2f4f6] px-5 py-4 border-b border-[#c6c6cd] flex justify-between items-center">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[#ba1a1a]">notifications_active</span>
            <h2 className="text-[15px] font-bold text-[#191c1e]">
              Alertas del Sistema ({alerts.length})
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-[#45464d] hover:text-[#191c1e] p-1 cursor-pointer"
          >
            ✕
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {alerts.length === 0 ? (
            <div className="text-center py-12 text-[#45464d] text-sm">
              <span className="material-symbols-outlined text-3xl mb-2 text-[#16a34a]">check_circle</span>
              <p>No hay alertas críticas pendientes.</p>
            </div>
          ) : (
            alerts.map((alert) => (
              <div
                key={alert.id}
                className={`p-3.5 rounded border text-[13px] relative transition-all ${
                  alert.severity === 'critical'
                    ? 'bg-[#fff5f5] border-[#fecaca]'
                    : alert.severity === 'warning'
                    ? 'bg-[#fefce8] border-[#fef08a]'
                    : 'bg-[#f7f9fb] border-[#c6c6cd]'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-1.5 font-semibold text-[#191c1e]">
                    <span
                      className={`material-symbols-outlined text-[16px] ${
                        alert.severity === 'critical'
                          ? 'text-[#ba1a1a]'
                          : alert.severity === 'warning'
                          ? 'text-[#854d0e]'
                          : 'text-[#45464d]'
                      }`}
                    >
                      {alert.severity === 'critical' ? 'error' : 'warning'}
                    </span>
                    <span>{alert.title}</span>
                  </div>
                  <button
                    onClick={() => onDismissAlert(alert.id)}
                    className="text-[#76777d] hover:text-[#191c1e] text-xs cursor-pointer"
                    title="Descartar"
                  >
                    ✕
                  </button>
                </div>
                <p className="text-[12px] text-[#45464d] mt-1">{alert.desc}</p>
                <div className="flex justify-between items-center mt-2 pt-2 border-t border-black/5 text-[11px] text-[#76777d]">
                  <span>{alert.time}</span>
                  <button
                    onClick={() => onDismissAlert(alert.id)}
                    className="text-[#000000] font-medium hover:underline cursor-pointer"
                  >
                    Marcar atendida
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        <div className="p-4 bg-[#f2f4f6] border-t border-[#c6c6cd]">
          <button
            onClick={onClose}
            className="w-full py-2 bg-white border border-[#c6c6cd] rounded text-[12px] font-medium text-[#191c1e] hover:bg-[#e0e3e5] cursor-pointer"
          >
            Cerrar panel
          </button>
        </div>
      </div>
    </div>
  );
};
