import React from 'react';
import { NavigationTab } from '../types';

interface MobileBottomNavProps {
  currentTab: NavigationTab;
  onSelectTab: (tab: NavigationTab) => void;
  onOpenMore: () => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  currentTab,
  onSelectTab,
  onOpenMore,
}) => {
  return (
    <nav
      id="mobile-bottom-navbar"
      className="fixed bottom-0 left-0 right-0 w-full bg-white border-t border-[#c6c6cd] flex justify-around items-center h-[64px] z-40 md:hidden shadow-lg"
    >
      <button
        id="mobile-nav-dashboard"
        onClick={() => onSelectTab('dashboard')}
        className={`flex flex-col items-center justify-center w-full h-full cursor-pointer transition-colors ${
          currentTab === 'dashboard'
            ? 'text-[#000000] border-t-2 border-[#000000] bg-[#eceef0]/40'
            : 'text-[#45464d] hover:text-[#191c1e]'
        }`}
      >
        <span
          className="material-symbols-outlined text-[22px]"
          style={{ fontVariationSettings: currentTab === 'dashboard' ? "'FILL' 1" : "'FILL' 0" }}
        >
          dashboard
        </span>
        <span className="text-[10px] font-medium mt-1">Dashboard</span>
      </button>

      <button
        id="mobile-nav-location"
        onClick={() => onSelectTab('location')}
        className={`flex flex-col items-center justify-center w-full h-full cursor-pointer transition-colors ${
          currentTab === 'location'
            ? 'text-[#000000] border-t-2 border-[#000000] bg-[#eceef0]/40'
            : 'text-[#45464d] hover:text-[#191c1e]'
        }`}
      >
        <span
          className="material-symbols-outlined text-[22px]"
          style={{ fontVariationSettings: currentTab === 'location' ? "'FILL' 1" : "'FILL' 0" }}
        >
          location_on
        </span>
        <span className="text-[10px] font-medium mt-1">Location</span>
      </button>

      <button
        id="mobile-nav-management"
        onClick={() => onSelectTab('management')}
        className={`flex flex-col items-center justify-center w-full h-full cursor-pointer transition-colors ${
          currentTab === 'management'
            ? 'text-[#000000] border-t-2 border-[#000000] bg-[#eceef0]/40'
            : 'text-[#45464d] hover:text-[#191c1e]'
        }`}
      >
        <span
          className="material-symbols-outlined text-[22px]"
          style={{ fontVariationSettings: currentTab === 'management' ? "'FILL' 1" : "'FILL' 0" }}
        >
          inventory_2
        </span>
        <span className="text-[10px] font-medium mt-1">Management</span>
      </button>

      <button
        id="mobile-nav-more"
        onClick={onOpenMore}
        className={`flex flex-col items-center justify-center w-full h-full cursor-pointer transition-colors ${
          currentTab === 'analytics' || currentTab === 'reports'
            ? 'text-[#000000] border-t-2 border-[#000000] bg-[#eceef0]/40'
            : 'text-[#45464d] hover:text-[#191c1e]'
        }`}
      >
        <span className="material-symbols-outlined text-[22px]">menu</span>
        <span className="text-[10px] font-medium mt-1">More</span>
      </button>
    </nav>
  );
};
