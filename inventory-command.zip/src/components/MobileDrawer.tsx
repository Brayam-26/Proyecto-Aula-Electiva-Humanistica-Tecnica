import React from 'react';
import { NavigationTab } from '../types';
import { LOGO_URL } from '../data/mockData';

interface MobileDrawerProps {
  isOpen: boolean;
  currentTab: NavigationTab;
  onSelectTab: (tab: NavigationTab) => void;
  onClose: () => void;
  onOpenExport: () => void;
  onOpenSettings: () => void;
  onOpenSupport: () => void;
}

export const MobileDrawer: React.FC<MobileDrawerProps> = ({
  isOpen,
  currentTab,
  onSelectTab,
  onClose,
  onOpenExport,
  onOpenSettings,
  onOpenSupport,
}) => {
  if (!isOpen) return null;

  const handleNav = (tab: NavigationTab) => {
    onSelectTab(tab);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 bg-black/50 z-50 flex backdrop-blur-xs md:hidden"
      onClick={onClose}
    >
      <div
        className="w-[280px] bg-[#f2f4f6] h-full flex flex-col shadow-2xl border-r border-[#c6c6cd]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-6 border-b border-[#c6c6cd] flex flex-col items-center relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-[#45464d] hover:text-[#191c1e] p-1"
          >
            ✕
          </button>
          <div className="w-14 h-14 rounded-full bg-[#e0e3e5] flex items-center justify-center mb-2 overflow-hidden border border-[#76777d]">
            <img alt="Organization Logo" className="object-cover w-full h-full" src={LOGO_URL} />
          </div>
          <h1 className="text-[18px] font-bold text-[#191c1e] text-center">Global Supply</h1>
          <p className="text-[11px] text-[#45464d] text-center">Enterprise Tier</p>
        </div>

        {/* Links */}
        <div className="flex-1 py-4 overflow-y-auto space-y-1 px-3">
          {[
            { id: 'dashboard', label: 'Dashboard', icon: 'dashboard' },
            { id: 'location', label: 'Location', icon: 'location_on' },
            { id: 'management', label: 'Management', icon: 'inventory_2' },
            { id: 'analytics', label: 'Analytics', icon: 'insights' },
            { id: 'reports', label: 'Reports', icon: 'description' },
          ].map((item) => {
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNav(item.id as NavigationTab)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded text-[13px] font-medium transition-colors text-left ${
                  isActive
                    ? 'bg-[#000000] text-white font-semibold'
                    : 'text-[#45464d] hover:bg-[#e0e3e5] hover:text-[#191c1e]'
                }`}
              >
                <span className="material-symbols-outlined text-[20px]">{item.icon}</span>
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>

        {/* Action & Footer */}
        <div className="p-4 border-t border-[#c6c6cd] space-y-3">
          <button
            onClick={() => {
              onClose();
              onOpenExport();
            }}
            className="w-full bg-[#000000] text-white py-2 px-3 rounded text-[12px] font-medium hover:bg-[#131b2e] flex items-center justify-center gap-1.5"
          >
            <span className="material-symbols-outlined text-[16px]">file_download</span>
            Export Data
          </button>

          <div className="flex flex-col space-y-1 text-[12px]">
            <button
              onClick={() => {
                onClose();
                onOpenSettings();
              }}
              className="flex items-center gap-3 px-3 py-2 text-[#45464d] hover:text-[#191c1e] text-left rounded hover:bg-[#e0e3e5]"
            >
              <span className="material-symbols-outlined text-[18px]">settings</span>
              <span>Settings</span>
            </button>
            <button
              onClick={() => {
                onClose();
                onOpenSupport();
              }}
              className="flex items-center gap-3 px-3 py-2 text-[#45464d] hover:text-[#191c1e] text-left rounded hover:bg-[#e0e3e5]"
            >
              <span className="material-symbols-outlined text-[18px]">help</span>
              <span>Support</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
