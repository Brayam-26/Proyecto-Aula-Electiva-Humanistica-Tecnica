import React, { useEffect, useRef } from 'react';
import Chart from 'chart.js/auto';
import { MONTHLY_CONSUMPTION, CATEGORY_DISTRIBUTION } from '../data/mockData';

export const AnalyticsView: React.FC = () => {
  const comparisonCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const comparisonChartRef = useRef<Chart | null>(null);

  const deptCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const deptChartRef = useRef<Chart | null>(null);

  useEffect(() => {
    // 1. Comparison Chart: Entregas vs Consumos
    if (comparisonCanvasRef.current) {
      if (comparisonChartRef.current) comparisonChartRef.current.destroy();
      const ctx = comparisonCanvasRef.current.getContext('2d');
      if (ctx) {
        comparisonChartRef.current = new Chart(ctx, {
          type: 'bar',
          data: {
            labels: MONTHLY_CONSUMPTION.map((m) => m.month),
            datasets: [
              {
                label: 'Entregas (Stock In)',
                data: MONTHLY_CONSUMPTION.map((m) => m.deliveries),
                backgroundColor: '#0F172A',
                borderRadius: 3,
              },
              {
                label: 'Consumo (Stock Out)',
                data: MONTHLY_CONSUMPTION.map((m) => m.consumption),
                backgroundColor: '#94A3B8',
                borderRadius: 3,
              },
            ],
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                position: 'top',
                labels: { font: { family: 'Inter', size: 12 }, color: '#191C1E' },
              },
            },
            scales: {
              x: { grid: { display: false } },
              y: {
                grid: { color: '#E2E8F0' },
                ticks: { font: { family: 'Inter', size: 11 } },
              },
            },
          },
        });
      }
    }

    // 2. Department distribution doughnut
    if (deptCanvasRef.current) {
      if (deptChartRef.current) deptChartRef.current.destroy();
      const ctx = deptCanvasRef.current.getContext('2d');
      if (ctx) {
        deptChartRef.current = new Chart(ctx, {
          type: 'doughnut',
          data: {
            labels: ['IT Infrastructure', 'Logistics', 'Facilities', 'Engineering'],
            datasets: [
              {
                data: [48, 26, 14, 12],
                backgroundColor: ['#0F172A', '#334155', '#64748B', '#94A3B8'],
                borderWidth: 2,
                borderColor: '#ffffff',
              },
            ],
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                position: 'bottom',
                labels: { font: { family: 'Inter', size: 11 }, color: '#191C1E' },
              },
            },
          },
        });
      }
    }

    return () => {
      comparisonChartRef.current?.destroy();
      deptChartRef.current?.destroy();
    };
  }, []);

  return (
    <div className="p-6 md:p-10 max-w-[1440px] mx-auto w-full space-y-6">
      {/* Header */}
      <div className="pb-4 border-b border-[#c6c6cd]">
        <h2 className="text-[24px] font-semibold text-[#191c1e] tracking-tight">
          Operational Analytics & Trends
        </h2>
        <p className="text-[14px] text-[#45464d] mt-1">
          Análisis avanzado de tasas de rotación, balance de entradas vs salidas y proyecciones de demanda.
        </p>
      </div>

      {/* Analytics KPI strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <div className="bg-white border border-[#c6c6cd] p-5 rounded-[2px] shadow-2xs">
          <span className="text-[12px] font-medium text-[#45464d] uppercase tracking-wider block">
            Índice de Rotación (Turnover Rate)
          </span>
          <div className="text-[32px] font-bold text-[#191c1e] mt-1">4.8x</div>
          <span className="text-[12px] text-[#16a34a] font-medium">+0.6x sobre objetivo semestral</span>
        </div>
        <div className="bg-white border border-[#c6c6cd] p-5 rounded-[2px] shadow-2xs">
          <span className="text-[12px] font-medium text-[#45464d] uppercase tracking-wider block">
            Tiempo Medio de Despacho
          </span>
          <div className="text-[32px] font-bold text-[#191c1e] mt-1">1.4 días</div>
          <span className="text-[12px] text-[#16a34a] font-medium">-18% de reducción en latencia</span>
        </div>
        <div className="bg-white border border-[#c6c6cd] p-5 rounded-[2px] shadow-2xs">
          <span className="text-[12px] font-medium text-[#45464d] uppercase tracking-wider block">
            Tasa de Utilización de Activos
          </span>
          <div className="text-[32px] font-bold text-[#191c1e] mt-1">92.4%</div>
          <span className="text-[12px] text-[#45464d]">8,902 activos en operación continua</span>
        </div>
      </div>

      {/* Charts Bento */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Entregas vs Consumo */}
        <div className="bg-white border border-[#c6c6cd] p-6 rounded-[2px] lg:col-span-2 shadow-2xs">
          <h3 className="text-[18px] font-bold text-[#191c1e] mb-4">
            Balance Semestral: Entregas vs Consumo
          </h3>
          <div className="h-[320px] w-full">
            <canvas ref={comparisonCanvasRef} />
          </div>
        </div>

        {/* Gerencias Doughnut */}
        <div className="bg-white border border-[#c6c6cd] p-6 rounded-[2px] shadow-2xs flex flex-col justify-between">
          <h3 className="text-[18px] font-bold text-[#191c1e] mb-2">
            Distribución por Gerencia
          </h3>
          <div className="h-[280px] w-full relative">
            <canvas ref={deptCanvasRef} />
          </div>
        </div>
      </div>

      {/* Category breakdown table */}
      <div className="bg-white border border-[#c6c6cd] p-6 rounded-[2px] shadow-2xs">
        <h3 className="text-[18px] font-bold text-[#191c1e] mb-4">
          Resumen de Existencias por Categoría
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {CATEGORY_DISTRIBUTION.map((cat) => (
            <div key={cat.name} className="p-3 bg-[#f7f9fb] border border-[#c6c6cd] rounded">
              <span className="text-[12px] font-medium text-[#45464d] block">{cat.name}</span>
              <span className="text-[20px] font-bold text-[#191c1e] mt-1 block">
                {cat.units.toLocaleString()}
              </span>
              <span className="text-[11px] text-[#16a34a] font-medium">En stock activo</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
