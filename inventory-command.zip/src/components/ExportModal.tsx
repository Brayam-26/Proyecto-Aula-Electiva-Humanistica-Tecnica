import React, { useState } from 'react';
import { Asset, Transaction } from '../types';

interface ExportModalProps {
  assets: Asset[];
  transactions: Transaction[];
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  assets,
  transactions,
  onClose,
}) => {
  const [exportType, setExportType] = useState<'assets' | 'transactions' | 'all'>('assets');
  const [format, setFormat] = useState<'csv' | 'json'>('csv');
  const [isCopied, setIsCopied] = useState(false);

  const generateData = () => {
    if (format === 'json') {
      const payload = {
        exportedAt: new Date().toISOString(),
        organization: 'Global Supply - Enterprise Tier',
        assets: exportType === 'transactions' ? undefined : assets,
        transactions: exportType === 'assets' ? undefined : transactions,
      };
      return JSON.stringify(payload, null, 2);
    } else {
      // CSV format
      if (exportType === 'assets' || exportType === 'all') {
        const headers = ['Asset ID', 'Type', 'Category', 'Location', 'Region', 'Department', 'Status', 'Deployment Date', 'Serial Number', 'Cost'];
        const rows = assets.map((a) => [
          a.id,
          `"${a.type}"`,
          a.category,
          `"${a.location}"`,
          a.region,
          `"${a.department}"`,
          a.status,
          a.deploymentDate,
          a.serialNumber,
          a.cost || 0,
        ]);
        return [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
      } else {
        const headers = ['Transaction ID', 'Type', 'Destination', 'Units', 'Status', 'Date', 'Time', 'Operator'];
        const rows = transactions.map((t) => [
          t.id,
          t.type,
          `"${t.destination}"`,
          t.units,
          t.status,
          t.date,
          t.time,
          `"${t.operator}"`,
        ]);
        return [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
      }
    }
  };

  const handleDownload = () => {
    const data = generateData();
    const blob = new Blob([data], {
      type: format === 'json' ? 'application/json' : 'text/csv;charset=utf-8;',
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `inventory_command_export_${exportType}_${new Date().toISOString().slice(0, 10)}.${format}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleCopy = () => {
    const data = generateData();
    navigator.clipboard.writeText(data);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  return (
    <div
      className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4 backdrop-blur-xs"
      onClick={onClose}
    >
      <div
        className="bg-white rounded border border-[#c6c6cd] shadow-xl w-full max-w-md overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="bg-[#f2f4f6] px-6 py-4 border-b border-[#c6c6cd] flex justify-between items-center">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[20px] text-[#000000]">file_download</span>
            <h2 className="text-[16px] font-bold text-[#191c1e]">Exportar Datos del Sistema</h2>
          </div>
          <button
            onClick={onClose}
            className="text-[#45464d] hover:text-[#191c1e] p-1 rounded cursor-pointer"
          >
            ✕
          </button>
        </div>

        <div className="p-6 space-y-4">
          <div>
            <label className="text-[12px] font-medium text-[#45464d] block mb-1">
              Colección a exportar
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setExportType('assets')}
                className={`py-2 px-3 text-[12px] font-medium rounded border cursor-pointer ${
                  exportType === 'assets'
                    ? 'bg-[#000000] text-white border-[#000000]'
                    : 'bg-white border-[#c6c6cd] text-[#191c1e] hover:bg-[#f2f4f6]'
                }`}
              >
                Activos ({assets.length})
              </button>
              <button
                type="button"
                onClick={() => setExportType('transactions')}
                className={`py-2 px-3 text-[12px] font-medium rounded border cursor-pointer ${
                  exportType === 'transactions'
                    ? 'bg-[#000000] text-white border-[#000000]'
                    : 'bg-white border-[#c6c6cd] text-[#191c1e] hover:bg-[#f2f4f6]'
                }`}
              >
                Transacciones
              </button>
              <button
                type="button"
                onClick={() => setExportType('all')}
                className={`py-2 px-3 text-[12px] font-medium rounded border cursor-pointer ${
                  exportType === 'all'
                    ? 'bg-[#000000] text-white border-[#000000]'
                    : 'bg-white border-[#c6c6cd] text-[#191c1e] hover:bg-[#f2f4f6]'
                }`}
              >
                Completo
              </button>
            </div>
          </div>

          <div>
            <label className="text-[12px] font-medium text-[#45464d] block mb-1">
              Formato de archivo
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setFormat('csv')}
                className={`py-2 px-3 text-[12px] font-medium rounded border cursor-pointer flex items-center justify-center gap-1.5 ${
                  format === 'csv'
                    ? 'bg-[#000000] text-white border-[#000000]'
                    : 'bg-white border-[#c6c6cd] text-[#191c1e] hover:bg-[#f2f4f6]'
                }`}
              >
                <span className="material-symbols-outlined text-[16px]">table_chart</span>
                CSV (Excel / Sheets)
              </button>
              <button
                type="button"
                onClick={() => setFormat('json')}
                className={`py-2 px-3 text-[12px] font-medium rounded border cursor-pointer flex items-center justify-center gap-1.5 ${
                  format === 'json'
                    ? 'bg-[#000000] text-white border-[#000000]'
                    : 'bg-white border-[#c6c6cd] text-[#191c1e] hover:bg-[#f2f4f6]'
                }`}
              >
                <span className="material-symbols-outlined text-[16px]">data_object</span>
                JSON Estructurado
              </button>
            </div>
          </div>

          <div className="p-3 bg-[#f7f9fb] border border-[#c6c6cd] rounded text-[12px] text-[#45464d]">
            Los datos exportados reflejan los filtros activos y la última sincronización en tiempo real de los centros de datos.
          </div>
        </div>

        <div className="bg-[#f2f4f6] px-6 py-3 border-t border-[#c6c6cd] flex justify-between items-center">
          <button
            type="button"
            onClick={handleCopy}
            className="text-[12px] text-[#000000] hover:underline flex items-center gap-1 cursor-pointer font-medium"
          >
            <span className="material-symbols-outlined text-[16px]">content_copy</span>
            {isCopied ? '¡Copiado!' : 'Copiar al portapapeles'}
          </button>
          <div className="flex gap-2">
            <button
              onClick={onClose}
              className="px-3 py-1.5 text-[12px] font-medium border border-[#c6c6cd] rounded hover:bg-[#f2f4f6] cursor-pointer"
            >
              Cerrar
            </button>
            <button
              onClick={handleDownload}
              className="px-4 py-1.5 bg-[#000000] text-white rounded text-[12px] font-medium hover:bg-[#131b2e] cursor-pointer flex items-center gap-1 shadow-sm"
            >
              <span className="material-symbols-outlined text-[16px]">download</span>
              Descargar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
