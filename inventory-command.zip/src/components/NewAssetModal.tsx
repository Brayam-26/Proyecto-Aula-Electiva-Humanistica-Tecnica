import React, { useState } from 'react';
import { Asset, FacilityLocation } from '../types';

interface NewAssetModalProps {
  locations: FacilityLocation[];
  onClose: () => void;
  onAddAsset: (newAsset: Asset) => void;
}

export const NewAssetModal: React.FC<NewAssetModalProps> = ({
  locations,
  onClose,
  onAddAsset,
}) => {
  const [formData, setFormData] = useState({
    id: `AST-${Math.floor(1000 + Math.random() * 9000)}`,
    type: 'Workstation Extreme',
    category: 'Computing' as Asset['category'],
    location: locations[0]?.name || 'Data Center Alpha',
    region: 'North America' as Asset['region'],
    department: 'IT Infrastructure' as Asset['department'],
    status: 'Active' as Asset['status'],
    serialNumber: `SN-${Math.floor(100000 + Math.random() * 900000)}`,
    assignedTo: '',
    cost: 3200,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newAsset: Asset = {
      ...formData,
      deploymentDate: new Date().toLocaleDateString('en-US', {
        month: 'short',
        day: '2-digit',
        year: 'numeric',
      }),
      healthScore: 100,
      lastMaintenance: 'Recently Deployed',
    };
    onAddAsset(newAsset);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4 backdrop-blur-xs"
      onClick={onClose}
    >
      <div
        className="bg-white rounded border border-[#c6c6cd] shadow-2xl w-full max-w-lg overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="bg-[#f2f4f6] px-6 py-4 border-b border-[#c6c6cd] flex justify-between items-center">
          <h2 className="text-[16px] font-bold text-[#191c1e]">Registrar Nuevo Activo Tecnológico</h2>
          <button
            onClick={onClose}
            className="text-[#45464d] hover:text-[#191c1e] p-1 rounded cursor-pointer"
          >
            ✕
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-[12px] font-medium text-[#45464d] block mb-1">
                Asset ID
              </label>
              <input
                type="text"
                value={formData.id}
                onChange={(e) => setFormData({ ...formData, id: e.target.value })}
                className="w-full bg-[#f7f9fb] border border-[#c6c6cd] rounded px-3 py-1.5 text-[13px] font-mono"
                required
              />
            </div>
            <div>
              <label className="text-[12px] font-medium text-[#45464d] block mb-1">
                Nombre / Modelo
              </label>
              <input
                type="text"
                value={formData.type}
                onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                className="w-full bg-[#f7f9fb] border border-[#c6c6cd] rounded px-3 py-1.5 text-[13px]"
                placeholder="ej. Server Rack, Core Switch"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-[12px] font-medium text-[#45464d] block mb-1">
                Categoría
              </label>
              <select
                value={formData.category}
                onChange={(e) =>
                  setFormData({ ...formData, category: e.target.value as any })
                }
                className="w-full bg-[#f7f9fb] border border-[#c6c6cd] rounded px-3 py-1.5 text-[13px]"
              >
                <option value="Computing">Computing</option>
                <option value="Networking">Networking</option>
                <option value="Storage">Storage</option>
                <option value="Peripherals">Peripherals</option>
                <option value="Mobile Devices">Mobile Devices</option>
                <option value="Displays">Displays</option>
              </select>
            </div>
            <div>
              <label className="text-[12px] font-medium text-[#45464d] block mb-1">
                Ubicación
              </label>
              <select
                value={formData.location}
                onChange={(e) => {
                  const loc = locations.find((l) => l.name === e.target.value);
                  setFormData({
                    ...formData,
                    location: e.target.value,
                    region: loc ? loc.region : formData.region,
                  });
                }}
                className="w-full bg-[#f7f9fb] border border-[#c6c6cd] rounded px-3 py-1.5 text-[13px]"
              >
                {locations.map((loc) => (
                  <option key={loc.id} value={loc.name}>
                    {loc.name} ({loc.city})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-[12px] font-medium text-[#45464d] block mb-1">
                Gerencia
              </label>
              <select
                value={formData.department}
                onChange={(e) =>
                  setFormData({ ...formData, department: e.target.value as any })
                }
                className="w-full bg-[#f7f9fb] border border-[#c6c6cd] rounded px-3 py-1.5 text-[13px]"
              >
                <option value="IT Infrastructure">IT Infrastructure</option>
                <option value="Logistics">Logistics</option>
                <option value="Facilities">Facilities</option>
                <option value="Engineering">Engineering</option>
              </select>
            </div>
            <div>
              <label className="text-[12px] font-medium text-[#45464d] block mb-1">
                Estado Inicial
              </label>
              <select
                value={formData.status}
                onChange={(e) =>
                  setFormData({ ...formData, status: e.target.value as any })
                }
                className="w-full bg-[#f7f9fb] border border-[#c6c6cd] rounded px-3 py-1.5 text-[13px]"
              >
                <option value="Active">Active</option>
                <option value="Maintenance">Maintenance</option>
                <option value="Retired">Retired</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-[12px] font-medium text-[#45464d] block mb-1">
                Número de Serie
              </label>
              <input
                type="text"
                value={formData.serialNumber}
                onChange={(e) =>
                  setFormData({ ...formData, serialNumber: e.target.value })
                }
                className="w-full bg-[#f7f9fb] border border-[#c6c6cd] rounded px-3 py-1.5 text-[13px] font-mono"
                required
              />
            </div>
            <div>
              <label className="text-[12px] font-medium text-[#45464d] block mb-1">
                Costo / Valor Estimado (USD)
              </label>
              <input
                type="number"
                value={formData.cost}
                onChange={(e) =>
                  setFormData({ ...formData, cost: Number(e.target.value) })
                }
                className="w-full bg-[#f7f9fb] border border-[#c6c6cd] rounded px-3 py-1.5 text-[13px]"
                min="0"
                required
              />
            </div>
          </div>

          <div>
            <label className="text-[12px] font-medium text-[#45464d] block mb-1">
              Responsable / Asignado a
            </label>
            <input
              type="text"
              value={formData.assignedTo}
              onChange={(e) =>
                setFormData({ ...formData, assignedTo: e.target.value })
              }
              placeholder="ej. Equipo de Operaciones Cloud / Ing. Gómez"
              className="w-full bg-[#f7f9fb] border border-[#c6c6cd] rounded px-3 py-1.5 text-[13px]"
            />
          </div>

          <div className="pt-4 flex justify-end gap-3 border-t border-[#c6c6cd]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-[12px] font-medium border border-[#c6c6cd] rounded hover:bg-[#f2f4f6] cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-[12px] font-medium bg-[#000000] text-white rounded hover:bg-[#131b2e] cursor-pointer"
            >
              Guardar Activo
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
