import React, { useEffect, useRef, useState } from 'react';
import Chart from 'chart.js/auto';

export const WeeklyTrendChart: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const chartRef = useRef<Chart | null>(null);
  const [filter, setFilter] = useState<'all' | 'entregas' | 'consumos'>('all');

  useEffect(() => {
    if (!canvasRef.current) return;

    if (chartRef.current) {
      chartRef.current.destroy();
    }

    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;

    const days = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
    const entregasData = [180, 240, 210, 290, 310, 140, 75];
    const consumosData = [120, 160, 145, 190, 220, 95, 62];

    const datasets: any[] = [];

    if (filter === 'all' || filter === 'entregas') {
      datasets.push({
        label: 'Entregas',
        data: entregasData,
        borderColor: '#0F172A',
        backgroundColor: 'rgba(15, 23, 42, 0.08)',
        borderWidth: 2,
        pointBackgroundColor: '#0F172A',
        pointRadius: 3.5,
        tension: 0.3,
        fill: true,
      });
    }

    if (filter === 'all' || filter === 'consumos') {
      datasets.push({
        label: 'Consumos',
        data: consumosData,
        borderColor: '#ba1a1a',
        backgroundColor: 'rgba(186, 26, 26, 0.05)',
        borderWidth: 2,
        pointBackgroundColor: '#ba1a1a',
        pointRadius: 3.5,
        tension: 0.3,
        fill: true,
      });
    }

    chartRef.current = new Chart(ctx, {
      type: 'line',
      data: {
        labels: days,
        datasets,
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: true,
            position: 'top',
            labels: {
              boxWidth: 10,
              boxHeight: 10,
              font: { family: 'Inter', size: 11 },
              color: '#45464D',
            },
          },
          tooltip: {
            backgroundColor: '#191C1E',
            padding: 8,
            titleFont: { family: 'Inter', size: 11 },
            bodyFont: { family: 'Inter', size: 12, weight: 'bold' },
          },
        },
        scales: {
          x: {
            grid: { display: false },
            ticks: { font: { family: 'Inter', size: 10 }, color: '#45464D' },
          },
          y: {
            grid: { color: '#E2E8F0' },
            ticks: { font: { family: 'Inter', size: 10 }, color: '#45464D' },
          },
        },
      },
    });

    return () => {
      if (chartRef.current) {
        chartRef.current.destroy();
      }
    };
  }, [filter]);

  return (
    <div className="w-full">
      <div className="flex justify-between items-center mb-3 pb-2 border-b border-[#c6c6cd]">
        <h2 className="text-[16px] font-semibold text-[#191c1e]">Weekly Trend</h2>
        <div className="flex items-center gap-1">
          <button
            onClick={() =>
              setFilter((prev) =>
                prev === 'all' ? 'entregas' : prev === 'entregas' ? 'consumos' : 'all'
              )
            }
            className="text-[12px] font-medium text-[#000000] bg-[#f2f4f6] px-2.5 py-1 rounded hover:bg-[#e0e3e5] transition-colors border border-[#c6c6cd]"
          >
            Filtro: {filter === 'all' ? 'Ambos' : filter === 'entregas' ? 'Entregas' : 'Consumos'}
          </button>
        </div>
      </div>
      <div className="h-48 w-full relative">
        <canvas ref={canvasRef} id="mobileWeeklyChart" />
      </div>
    </div>
  );
};
