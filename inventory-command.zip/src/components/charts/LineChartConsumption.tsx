import React, { useEffect, useRef } from 'react';
import Chart from 'chart.js/auto';

interface LineChartConsumptionProps {
  data?: { month: string; consumption: number }[];
}

export const LineChartConsumption: React.FC<LineChartConsumptionProps> = ({
  data = [
    { month: 'Jan', consumption: 3100 },
    { month: 'Feb', consumption: 3250 },
    { month: 'Mar', consumption: 3150 },
    { month: 'Apr', consumption: 3400 },
    { month: 'May', consumption: 3300 },
    { month: 'Jun', consumption: 3291 },
  ],
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const chartRef = useRef<Chart | null>(null);

  useEffect(() => {
    if (!canvasRef.current) return;

    if (chartRef.current) {
      chartRef.current.destroy();
    }

    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;

    const labels = data.map((d) => d.month);
    const consumptionValues = data.map((d) => d.consumption);

    chartRef.current = new Chart(ctx, {
      type: 'line',
      data: {
        labels,
        datasets: [
          {
            label: 'Consumption',
            data: consumptionValues,
            borderColor: '#0F172A',
            borderWidth: 2,
            pointBackgroundColor: '#FFFFFF',
            pointBorderColor: '#0F172A',
            pointBorderWidth: 2,
            pointRadius: 4.5,
            pointHoverRadius: 7,
            fill: true,
            backgroundColor: function (context) {
              const chart = context.chart;
              const { ctx: cCtx, chartArea } = chart;
              if (!chartArea) return 'rgba(15, 23, 42, 0.05)';
              const gradient = cCtx.createLinearGradient(0, chartArea.bottom, 0, chartArea.top);
              gradient.addColorStop(0, 'rgba(15, 23, 42, 0)');
              gradient.addColorStop(1, 'rgba(15, 23, 42, 0.12)');
              return gradient;
            },
            tension: 0.35,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: '#191C1E',
            titleFont: { family: 'Inter', size: 12 },
            bodyFont: { family: 'Inter', size: 13, weight: 'bold' },
            padding: 10,
            cornerRadius: 4,
            displayColors: false,
            callbacks: {
              label: (context) => `${context.parsed.y?.toLocaleString()} units consumed`,
            },
          },
        },
        scales: {
          x: {
            grid: { display: false },
            ticks: {
              font: { family: 'Inter', size: 11 },
              color: '#45464D',
            },
          },
          y: {
            min: 2500,
            max: 3500,
            grid: {
              color: '#E2E8F0',
            },
            ticks: {
              stepSize: 500,
              font: { family: 'Inter', size: 11 },
              color: '#45464D',
              callback: (val) => val.toLocaleString(),
            },
          },
        },
      },
    });

    return () => {
      if (chartRef.current) {
        chartRef.current.destroy();
      }
    };
  }, [data]);

  return (
    <div className="w-full h-full min-h-[280px] relative">
      <canvas ref={canvasRef} id="lineChart" />
    </div>
  );
};
