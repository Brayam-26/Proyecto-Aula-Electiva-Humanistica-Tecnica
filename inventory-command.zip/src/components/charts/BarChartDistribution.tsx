import React, { useEffect, useRef } from 'react';
import Chart from 'chart.js/auto';

interface BarChartDistributionProps {
  data?: { name: string; units: number }[];
  onCategoryClick?: (category: string) => void;
}

export const BarChartDistribution: React.FC<BarChartDistributionProps> = ({
  data = [
    { name: 'Computing', units: 4200 },
    { name: 'Networking', units: 2800 },
    { name: 'Storage', units: 1500 },
    { name: 'Peripherals', units: 3100 },
    { name: 'Mobile Devices', units: 2400 },
    { name: 'Displays', units: 1800 },
  ],
  onCategoryClick,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const chartRef = useRef<Chart | null>(null);

  useEffect(() => {
    if (!canvasRef.current) return;

    if (chartRef.current) {
      chartRef.current.destroy();
    }

    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;

    const labels = data.map((d) => d.name);
    const units = data.map((d) => d.units);

    chartRef.current = new Chart(ctx, {
      type: 'bar',
      data: {
        labels,
        datasets: [
          {
            label: 'Units',
            data: units,
            backgroundColor: '#0F172A',
            borderRadius: 4,
            barPercentage: 0.6,
            hoverBackgroundColor: '#1e293b',
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        onClick: (_, elements) => {
          if (elements.length > 0 && onCategoryClick) {
            const index = elements[0].index;
            onCategoryClick(labels[index]);
          }
        },
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: '#191C1E',
            titleFont: { family: 'Inter', size: 12 },
            bodyFont: { family: 'Inter', size: 14, weight: 'bold' },
            padding: 10,
            cornerRadius: 4,
            displayColors: false,
            callbacks: {
              label: (context) => `${context.parsed.y?.toLocaleString()} units in stock`,
            },
          },
        },
        scales: {
          x: {
            grid: { display: false },
            ticks: {
              font: { family: 'Inter', size: 11 },
              color: '#45464D',
            },
          },
          y: {
            min: 0,
            max: 6000,
            grid: {
              color: '#E2E8F0',
            },
            ticks: {
              font: { family: 'Inter', size: 12 },
              color: '#45464D',
              stepSize: 2000,
              callback: (val) => val.toLocaleString(),
            },
          },
        },
      },
    });

    return () => {
      if (chartRef.current) {
        chartRef.current.destroy();
      }
    };
  }, [data, onCategoryClick]);

  return (
    <div className="w-full h-full min-h-[280px] relative">
      <canvas ref={canvasRef} id="barChart" />
    </div>
  );
};
