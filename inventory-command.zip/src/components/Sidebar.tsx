import React from 'react';
import { NavigationTab } from '../types';
import { LOGO_URL } from '../data/mockData';

interface SidebarProps {
  currentTab: NavigationTab;
  onSelectTab: (tab: NavigationTab) => void;
  onOpenExport: () => void;
  onOpenSettings: () => void;
  onOpenSupport: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  onOpenExport,
  onOpenSettings,
  onOpenSupport,
}) => {
  const navItems: { id: NavigationTab; label: string; icon: string }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: 'dashboard' },
    { id: 'location', label: 'Location', icon: 'location_on' },
    { id: 'management', label: 'Management', icon: 'inventory_2' },
    { id: 'analytics', label: 'Analytics', icon: 'insights' },
    { id: 'reports', label: 'Reports', icon: 'description' },
  ];

  return (
    <nav
      id="sidebar-navigation"
      className="bg-[#f2f4f6] border-r border-[#c6c6cd] flex flex-col h-screen w-[240px] fixed left-0 top-0 z-40"
    >
      {/* Header */}
      <div className="p-6 border-b border-[#c6c6cd] flex flex-col items-center">
        <div className="w-16 h-16 rounded-full bg-[#e0e3e5] flex items-center justify-center mb-2 overflow-hidden border border-[#76777d]">
          <img
            alt="Organization Logo"
            className="object-cover w-full h-full"
            src={LOGO_URL}
          />
        </div>
        <h1 className="text-[20px] font-bold text-[#191c1e] text-center tracking-tight">
          Global Supply
        </h1>
        <p className="text-[12px] font-medium text-[#45464d] text-center tracking-wide">
          Enterprise Tier
        </p>
      </div>

      {/* Navigation Links */}
      <div className="flex-1 py-4 overflow-y-auto space-y-1 px-2">
        {navItems.map((item) => {
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              id={`nav-item-${item.id}`}
              onClick={() => onSelectTab(item.id)}
              className={`w-full flex items-center gap-4 px-4 py-2 cursor-pointer transition-all text-[12px] font-medium tracking-wide text-left ${
                isActive
                  ? 'text-[#000000] border-l-4 border-[#000000] bg-[#e0e3e5] font-semibold'
                  : 'text-[#45464d] hover:text-[#191c1e] hover:bg-[#e0e3e5] border-l-4 border-transparent'
              }`}
            >
              <span className="material-symbols-outlined text-[20px]">
                {item.icon}
              </span>
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>

      {/* CTA & Footer */}
      <div className="p-6 border-t border-[#c6c6cd] space-y-4">
        <button
          id="sidebar-export-button"
          onClick={onOpenExport}
          className="w-full bg-[#000000] text-white py-2 px-4 rounded-[2px] text-[12px] font-medium tracking-wide hover:bg-[#131b2e] transition-colors shadow-sm cursor-pointer active:scale-[0.98]"
        >
          Export Data
        </button>

        <div className="flex flex-col space-y-1">
          <button
            id="sidebar-settings-link"
            onClick={onOpenSettings}
            className="flex items-center gap-4 px-4 py-2 text-[#45464d] hover:text-[#191c1e] cursor-pointer hover:bg-[#e0e3e5] transition-all text-[12px] font-medium text-left"
          >
            <span className="material-symbols-outlined text-[20px]">settings</span>
            <span>Settings</span>
          </button>
          <button
            id="sidebar-support-link"
            onClick={onOpenSupport}
            className="flex items-center gap-4 px-4 py-2 text-[#45464d] hover:text-[#191c1e] cursor-pointer hover:bg-[#e0e3e5] transition-all text-[12px] font-medium text-left"
          >
            <span className="material-symbols-outlined text-[20px]">help</span>
            <span>Support</span>
          </button>
        </div>
      </div>
    </nav>
  );
};
